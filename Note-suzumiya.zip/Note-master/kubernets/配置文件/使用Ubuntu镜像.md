使用Ubuntu镜像 禁止重启

~~~
apiVersion: v1
kind: Pod
metadata:
  name: test5
  namespace: default
spec:
  restartPolicy: Never
  nodeName: neunode1
  containers:
  - name: test5
    image: ubuntu:iperf
    command: [ "/bin/bash", "-c", "--" ]
    args: [ "while true; do sleep 30; done;" ]
~~~

