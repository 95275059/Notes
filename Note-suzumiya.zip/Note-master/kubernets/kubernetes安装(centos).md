[TOC]

# kubernetes部署

环境：CentOS7.5

| 节点类型 | IP地址        | CPU  | 内存 | 硬盘 |
| -------- | ------------- | ---- | ---- | ---- |
| master   | 192.168.1.242 | 2    | 2    | 40   |
| node1    | 192.168.1.243 | 2    | 2    | 20   |

## 设置hosts解析

操作节点：所有节点（`master,node1`）均需执行

- **修改hostname**
  hostname必须只能包含小写字母、数字、","、"-"，且开头结尾必须是小写字母或数字

```python
# 在master节点
$ hostnamectl set-hostname master #设置master节点的hostname

# 在slave-1节点
$ hostnamectl set-hostname node1 #设置node1节点的hostname
```

- **添加hosts解析**

```python
$ cat >>/etc/hosts<<EOF
192.168.1.242 master
192.168.1.243 node1
EOF
```

## 调整系统配置

操作节点：所有节点（`master,node1`）均需执行

### 关闭swap

验证一下是否开启:

```bash
sudo swapon --show
```

如果输出不是空的说明开启了 swap，使用下面的命令禁用 swap:

```
sudo swapoff -a #暂时关闭
```

为了防止开机自动挂载 swap 分区，可以注释 /etc/fstab 中相应的条目:

```
sudo sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab
```

如果不关闭kubernetes运行会出现错误， 即使安装成功了，node重启后也会出现kubernetes server运行错误。

### 关闭防火墙

~~~
systemctl disable firewalld 
systemctl stop firewalld
~~~

### 关闭selinux

修改修改/etc/selinux/config 文件，将SELINUX=enforcing改为SELINUX=disabled，重启电脑后生效。修改如下

~~~
vim /etc/selinux/config
# This file controls the state of SELinux on the system.
# SELINUX= can take one of these three values:
#     enforcing - SELinux security policy is enforced.
#     permissive - SELinux prints warnings instead of enforcing.
#     disabled - No SELinux policy is loaded.
SELINUX=disabled
# SELINUXTYPE= can take one of three two values:
#     targeted - Targeted processes are protected,
#     minimum - Modification of targeted policy. Only selected processes are protected. 
#     mls - Multi Level Security protection.
SELINUXTYPE=targeted
~~~

临时关闭

~~~
setenforce 0 #设置SELinux 成为permissive模式
#setenforce 1 设置SELinux 成为enforcing模式
~~~

查看selinux状态

~~~
getenforce
~~~

>状态说明
>
>Enforcing：默认状态，表示强制启用
>
>Permissive：大部分规则都放行
>
>Disabled：禁用，即不设置任何规则

## 安装docker

操作节点：所有节点（`master,node1`）均需执行

### 配置docker yum源

~~~
curl -o /etc/yum.repos.d/docker-ce.repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
~~~

### 安装docker

~~~
yum install docker-ce
~~~

### 配置docker加速

~~~
mkdir -p /etc/docker
vim /etc/docker/daemon.json
{
  "registry-mirrors": ["https://9davbs13.mirror.aliyuncs.com"]
}

systemctl daemon-reload
systemctl restart docker
~~~

### 启动docker

~~~
 systemctl enable docker
 systemctl start docker
~~~

## 安装kubernetes

#### 添加kubernetes软件源

操作节点：所有节点（`master,node1`）均需执行

~~~
cat <<EOF > /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=http://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-x86_64
enabled=1
gpgcheck=0
repo_gpgcheck=0
gpgkey=http://mirrors.aliyun.com/kubernetes/yum/doc/yum-key.gpg
        http://mirrors.aliyun.com/kubernetes/yum/doc/rpm-package-key.gpg
EOF

yum clean all && yum makecache
~~~

#### 安装kubeadm, kubelet 和 kubectl

操作节点：所有节点（`master,node1`）均需执行

~~~
 yum install -y kubelet kubeadm kubectl
~~~

### 配置Master

#### 下载镜像

##### 获取镜像列表

由于官方镜像地址被墙，所以我们需要首先获取所需镜像以及它们的版本。然后从国内镜像站获取。

```
kubeadm config images list
```

输出如下

```
W0406 22:13:31.214585    3974 version.go:101] could not fetch a Kubernetes version from the internet: unable to get URL "https://dl.k8s.io/release/stable-1.txt": Get https://dl.k8s.io/release/stable-1.txt: net/http: request canceled while waiting for connection (Client.Timeout exceeded while awaiting headers)
W0406 22:13:31.214889    3974 version.go:102] falling back to the local client version: v1.17.3
W0406 22:13:31.215026    3974 validation.go:28] Cannot validate kube-proxy config - no validator is available
W0406 22:13:31.215036    3974 validation.go:28] Cannot validate kubelet config - no validator is available
k8s.gcr.io/kube-apiserver:v1.17.3
k8s.gcr.io/kube-controller-manager:v1.17.3
k8s.gcr.io/kube-scheduler:v1.17.3
k8s.gcr.io/kube-proxy:v1.17.3
k8s.gcr.io/pause:3.1
k8s.gcr.io/etcd:3.4.3-0
k8s.gcr.io/coredns:1.6.5
```

前面提示的警告信息可不理会。此处是确认本版本 kubeadm 匹配的镜像的版本，因为各组件版本不同可能出现兼容性问题。

##### 拉取镜像文件

一般地，国内无法直接下载 k8s.gcr.io 的镜像，可以通过下面的脚本从阿里云获取，创建脚本pullk8s.sh（注意脚本必须添加x属性）

```shell
images=( # 下面的镜像应该去除"k8s.gcr.io/"的前缀，版本换成上面获取到的版本
    kube-apiserver:v1.18.3
    kube-controller-manager:v1.18.3
    kube-scheduler:v1.18.3
    kube-proxy:v1.18.3
    pause:3.2
    etcd:3.4.3-0
    coredns:1.6.7
)

for imageName in ${images[@]} ; do
    docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/$imageName
    docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/$imageName k8s.gcr.io/$imageName
    docker rmi registry.cn-hangzhou.aliyuncs.com/google_containers/$imageName
done
```

运行该脚本

```
./pullk8s.sh
```

运行界面如下

![](.\微信图片_20200406222703.png)

#### 初始化

```
kubeadm init
```

如果需要其他配置，可以后面添加参数，输出如下：

```
I0406 22:44:59.671660    4825 version.go:251] remote version is much newer: v1.18.0; falling back to: stable-1.17
W0406 22:45:02.174368    4825 validation.go:28] Cannot validate kube-proxy config - no validator is available
W0406 22:45:02.174406    4825 validation.go:28] Cannot validate kubelet config - no validator is available
[init] Using Kubernetes version: v1.17.4
[preflight] Running pre-flight checks
	[WARNING IsDockerSystemdCheck]: detected "cgroupfs" as the Docker cgroup driver. The recommended driver is "systemd". Please follow the guide at https://kubernetes.io/docs/setup/cri/
[preflight] Pulling images required for setting up a Kubernetes cluster
[preflight] This might take a minute or two, depending on the speed of your internet connection
[preflight] You can also perform this action in beforehand using 'kubeadm config images pull'
[kubelet-start] Writing kubelet environment file with flags to file "/var/lib/kubelet/kubeadm-flags.env"
[kubelet-start] Writing kubelet configuration to file "/var/lib/kubelet/config.yaml"
[kubelet-start] Starting the kubelet
[certs] Using certificateDir folder "/etc/kubernetes/pki"
[certs] Generating "ca" certificate and key
[certs] Generating "apiserver" certificate and key
[certs] apiserver serving cert is signed for DNS names [master-virtual-machine kubernetes kubernetes.default kubernetes.default.svc kubernetes.default.svc.cluster.local] and IPs [10.96.0.1 192.168.100.3]
[certs] Generating "apiserver-kubelet-client" certificate and key
[certs] Generating "front-proxy-ca" certificate and key
[certs] Generating "front-proxy-client" certificate and key
[certs] Generating "etcd/ca" certificate and key
[certs] Generating "etcd/server" certificate and key
[certs] etcd/server serving cert is signed for DNS names [master-virtual-machine localhost] and IPs [192.168.100.3 127.0.0.1 ::1]
[certs] Generating "etcd/peer" certificate and key
[certs] etcd/peer serving cert is signed for DNS names [master-virtual-machine localhost] and IPs [192.168.100.3 127.0.0.1 ::1]
[certs] Generating "etcd/healthcheck-client" certificate and key
[certs] Generating "apiserver-etcd-client" certificate and key
[certs] Generating "sa" key and public key
[kubeconfig] Using kubeconfig folder "/etc/kubernetes"
[kubeconfig] Writing "admin.conf" kubeconfig file
[kubeconfig] Writing "kubelet.conf" kubeconfig file
[kubeconfig] Writing "controller-manager.conf" kubeconfig file
[kubeconfig] Writing "scheduler.conf" kubeconfig file
[control-plane] Using manifest folder "/etc/kubernetes/manifests"
[control-plane] Creating static Pod manifest for "kube-apiserver"
[control-plane] Creating static Pod manifest for "kube-controller-manager"
W0406 22:45:11.026958    4825 manifests.go:214] the default kube-apiserver authorization-mode is "Node,RBAC"; using "Node,RBAC"
[control-plane] Creating static Pod manifest for "kube-scheduler"
W0406 22:45:11.031675    4825 manifests.go:214] the default kube-apiserver authorization-mode is "Node,RBAC"; using "Node,RBAC"
[etcd] Creating static Pod manifest for local etcd in "/etc/kubernetes/manifests"
[wait-control-plane] Waiting for the kubelet to boot up the control plane as static Pods from directory "/etc/kubernetes/manifests". This can take up to 4m0s
[kubelet-check] Initial timeout of 40s passed.
[apiclient] All control plane components are healthy after 56.505057 seconds
[upload-config] Storing the configuration used in ConfigMap "kubeadm-config" in the "kube-system" Namespace
[kubelet] Creating a ConfigMap "kubelet-config-1.17" in namespace kube-system with the configuration for the kubelets in the cluster
[upload-certs] Skipping phase. Please see --upload-certs
[mark-control-plane] Marking the node master-virtual-machine as control-plane by adding the label "node-role.kubernetes.io/master=''"
[mark-control-plane] Marking the node master-virtual-machine as control-plane by adding the taints [node-role.kubernetes.io/master:NoSchedule]
[bootstrap-token] Using token: uhpiqf.p93x103die3kmc1r
[bootstrap-token] Configuring bootstrap tokens, cluster-info ConfigMap, RBAC Roles
[bootstrap-token] configured RBAC rules to allow Node Bootstrap tokens to post CSRs in order for nodes to get long term certificate credentials
[bootstrap-token] configured RBAC rules to allow the csrapprover controller automatically approve CSRs from a Node Bootstrap Token
[bootstrap-token] configured RBAC rules to allow certificate rotation for all node client certificates in the cluster
[bootstrap-token] Creating the "cluster-info" ConfigMap in the "kube-public" namespace
[kubelet-finalize] Updating "/etc/kubernetes/kubelet.conf" to point to a rotatable kubelet client certificate and key
[addons] Applied essential addon: CoreDNS
[addons] Applied essential addon: kube-proxy

Your Kubernetes control-plane has initialized successfully!

To start using your cluster, you need to run the following as a regular user:

  mkdir -p $HOME/.kube
  sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
  sudo chown $(id -u):$(id -g) $HOME/.kube/config

You should now deploy a pod network to the cluster.
Run "kubectl apply -f [podnetwork].yaml" with one of the options listed at:
  https://kubernetes.io/docs/concepts/cluster-administration/addons/

Then you can join any number of worker nodes by running the following on each as root:

kubeadm join 192.168.100.3:6443 --token uhpiqf.p93x103die3kmc1r \
    --discovery-token-ca-cert-hash sha256:411f471d9f4faa4c713ffe37180027f2d32b8fe59da43e613c27414214603399
```

首先确认了k8s版本。
接着创建配置文件，如证书等。
再创建 pod。
最后提示加入集群的命令。

如果忘记，可 kubeadm token create --print-join-command 查看

#### 创建用户

添加一个新用户（如用户名为ubuntu）

```
adduser ubuntu
```

为该用户设定登录密码

```
passwd ubuntu
```

> Ubuntu下普通用户用sudo执行命令时报"xxx is not in the sudoers file.This incident will be reported"错误，解决方法就是在/etc/sudoers文件里给该用户添加权限。如下：
>
> 1.切换到root用户下
>
> 2./etc/sudoers文件默认是只读的，对root来说也是，因此需先添加sudoers文件的写权限,命令是:
> chmod u+w /etc/sudoers
>
> 3. 编辑sudoers文件
>
> vim /etc/sudoers
> 找到这行 root ALL=(ALL) ALL,在他下面添加xxx ALL=(ALL) ALL (这里的xxx是你的用户名)
>
> ps:这里说下你可以sudoers添加下面四行中任意一条
> youuser      ALL=(ALL)        ALL
> %youuser     ALL=(ALL)        ALL
> youuser      ALL=(ALL)        NOPASSWD: ALL
> %youuser     ALL=(ALL)        NOPASSWD: ALL
>
> 第一行:允许用户youuser执行sudo命令(需要输入密码).
> 第二行:允许用户组youuser里面的用户执行sudo命令(需要输入密码).
> 第三行:允许用户youuser执行sudo命令,并且在执行的时候不输入密码.
> 第四行:允许用户组youuser里面的用户执行sudo命令,并且在执行的时候不输入密码.
>
> 4.撤销sudoers文件写权限,命令:
> chmod u-w /etc/sudoers

根据提示，根据拷贝 admin.conf 文件到当前用户相应目录下，这样不用每次都输入相关的认证信息。(在常规用户下使用以下命令）admin.conf 文件后续会使用到（需要拷贝到 node 节点）（待验证）。

```
mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config
```

#### 设置master节点是否可调度（可选）

操作节点：master

kubernetes官方默认策略是worker节点运行Pod，master节点不运行Pod。如果只是为了开发或者其他目的而需要部署单节点集群，可以通过以下的命令设置

```
kubectl taint nodes --all node-role.kubernetes.io/master-
```

#### 进行网络插件配置

见网络插件

#### 验证

```
kubectl get nodes
```

![](.\微信图片_20200407182242.png)

```
kubectl get pod --all-namespaces
```

![](.\微信图片_20200407182506.png)

如果出现类似上面的情况就说明安装完成了。

### 配置Node

#### 下载镜像

##### 获取镜像列表

由于官方镜像地址被墙，所以我们需要首先获取所需镜像以及它们的版本。然后从国内镜像站获取。

```
kubeadm config images list
```

输出如下

```
W0810 14:44:22.483636   73649 version.go:102] could not fetch a Kubernetes version from the internet: unable to get URL "https://dl.k8s.io/release/stable-1.txt": Get https://storage.googleapis.com/kubernetes-release/release/stable-1.txt: net/http: request canceled while waiting for connection (Client.Timeout exceeded while awaiting headers)
W0810 14:44:22.483693   73649 version.go:103] falling back to the local client version: v1.18.6
W0810 14:44:22.483955   73649 configset.go:202] WARNING: kubeadm cannot validate component configs for API groups [kubelet.config.k8s.io kubeproxy.config.k8s.io]
k8s.gcr.io/kube-apiserver:v1.18.6
k8s.gcr.io/kube-controller-manager:v1.18.6
k8s.gcr.io/kube-scheduler:v1.18.6
k8s.gcr.io/kube-proxy:v1.18.6
k8s.gcr.io/pause:3.2
k8s.gcr.io/etcd:3.4.3-0
k8s.gcr.io/coredns:1.6.7
```

前面提示的警告信息可不理会。此处是确认本版本 kubeadm 匹配的镜像的版本，因为各组件版本不同可能出现兼容性问题。

##### 拉取镜像文件

一般地，国内无法直接下载 k8s.gcr.io 的镜像，可以通过下面的脚本从阿里云获取，创建脚本pullk8s.sh（注意脚本必须添加x属性）。node节点中不需要安装全部镜像，只需要安装以下即可。

```shell
images=( # 下面的镜像应该去除"k8s.gcr.io/"的前缀，版本换成上面获取到的版本
    kube-proxy:v1.18.3
    pause:3.2
    etcd:3.4.3-0
    coredns:1.6.7
)

for imageName in ${images[@]} ; do
    docker pull registry.cn-hangzhou.aliyuncs.com/google_containers/$imageName
    docker tag registry.cn-hangzhou.aliyuncs.com/google_containers/$imageName k8s.gcr.io/$imageName
    docker rmi registry.cn-hangzhou.aliyuncs.com/google_containers/$imageName
done
```

运行该脚本，下载镜像

```
./pullk8s.sh
```

#### 加入master（使用root用户）

在**master节点**查看token是否可用

~~~shell
kubeadm token list
#输出
TOKEN                     TTL         EXPIRES                     USAGES                   DESCRIPTION                                                EXTRA GROUPS
878fz6.v4yc7njgb4evijso   57m         2020-08-10T15:59:08+08:00   authentication,signing   <none>                                                     system:bootstrappers:kubeadm:default-node-token
ashpqo.q9zrm0nkfxsgndv8   32m         2020-08-10T15:34:18+08:00   authentication,signing   <none>                                                     system:bootstrappers:kubeadm:default-node-token
~~~

##### 若token可用

在**master节点**还在则获取ca证书sha256编码hash值

~~~shell
openssl x509 -pubkey -in /etc/kubernetes/pki/ca.crt | openssl rsa -pubin -outform der 2>/dev/null | openssl dgst -sha256 -hex | sed 's/^.* //
#输出
def0d84163e440ed10d7b85e2c54c01bea3d1d26df422be7f396464c188a35d0
~~~

在**node节点**执行以下命令，将node节点加入master节点

```shell
kubeadm join 192.168.1.242:6443 --token ashpqo.q9zrm0nkfxsgndv8     --discovery-token-ca-cert-hash sha256:def0d84163e440ed10d7b85e2c54c01bea3d1d26df422be7f396464c188a35d0 
```

##### 若token不可用

在**master节点**生成一个新的token，默认有效期24小时,若想久一些可以结合--ttl参数,设为0则永不过期

~~~shell
kubeadm token create --print-join-command
#输出
kubeadm join 192.168.1.242:6443 --token rmq6m4.mtlsco5bk1lgqxh3     --discovery-token-ca-cert-hash sha256:def0d84163e440ed10d7b85e2c54c01bea3d1d26df422be7f396464c188a35d0 
~~~

在**node节点**执行以下命令，将node节点加入master节点

~~~shell
kubeadm join 192.168.1.242:6443 --token rmq6m4.mtlsco5bk1lgqxh3     --discovery-token-ca-cert-hash sha256:def0d84163e440ed10d7b85e2c54c01bea3d1d26df422be7f396464c188a35d0 
~~~

**注意：**在加入到master节点前，查看kubelet服务，显示failed

#### 在加入master遇到如下错误

在**node节点**使用join命令加入master时遇到错误

~~~
[preflight] Running pre-flight checks.
    [WARNING FileExisting-crictl]: crictl not found in system path
[preflight] Some fatal errors occurred:
    [ERROR FileContent--proc-sys-net-bridge-bridge-nf-call-iptables]: /proc/sys/net/bridge/bridge-nf-call-iptables contents are not set to 1
    [ERROR Swap]: running with swap on is not supported. Please disable swap
[preflight] If you know what you are doing, you can make a check non-fatal with `--ignore-preflight-errors=...`
~~~

解决方案

在**node节点**上执行

~~~
$ echo 1 > /proc/sys/net/bridge/bridge-nf-call-iptables
$ echo 1 > /proc/sys/net/bridge/bridge-nf-call-ip6tables
~~~



#### Master上检查运行情况









**参考：**https://yangsijie151104.gitbook.io/k8s-note/kubernetes-an-zhuang/1.kubernetes-an-zhuang/shi-yong-kubeadm-an-zhuang

https://zhuanlan.zhihu.com/p/46341911

https://developer.aliyun.com/article/701252

https://blog.csdn.net/zhydream77/article/details/81909939

笔记：Kubernetes 安装手册（非高可用版）

