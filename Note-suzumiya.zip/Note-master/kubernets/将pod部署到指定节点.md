# 将pod部署到指定节点

## 通过label-selector机制选择节点

~~~
Pod.spec.nodeSelector
~~~

#### 添加disktype标签

1. 选择一个节点，给这个节点添加标签

   ~~~shell
   kubectl label nodes <node-name> <label-key>=<label-value> 
   
   #e.g.
   kubectl label nodes nuenode1 disktype=ssd
   ~~~

2. 查看节点标签

   ~~~shell
   kubectl get nodes --show-labels
   
   NAME        STATUS   ROLES    AGE   VERSION   LABELS
   k8smaster   Ready    master   54d   v1.18.3   beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,disktype=scsi,kubernetes.io/arch=amd64,kubernetes.io/hostname=k8smaster,kubernetes.io/os=linux,node-role.kubernetes.io/master=
   neunode1    Ready    <none>   42h   v1.18.6   beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,disktype=ssd,kubernetes.io/arch=amd64,kubernetes.io/hostname=neunode1,kubernetes.io/os=linux,zone=node1
   ~~~

   上面输出可以看出，neunode1节点包含disktype=ssd标签。

3. 创建pod配置文件pod.yaml。该配置文件包含个节点选择器disktype:ssd。这意味着这个pod将调度到含有disktype=ssd标签的节点。

   ~~~yaml
   apiVersion: v1
   kind: Pod
   metadata:
     name: busybox11
     namespace: default
   spec:
     nodeSelector:
       disktype: ssd
     containers:
     - name: busybox11
       image: busybox
       command: ["sleep"]
       args: ["1000"]
   ~~~

4. 使用该配置文件进行部署

   ~~~
   kubectl create -f pod.yaml
   ~~~

#### 添加type标签

1. 选择一个节点，给这个节点添加标签

   ```shell
   kubectl label nodes nuenode1 type=node1
   ```

2. 查看节点标签

   ```shell
   kubectl get nodes --show-labels
   
   NAME        STATUS   ROLES    AGE   VERSION   LABELS
   k8smaster   Ready    master   54d   v1.18.3   beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,disktype=scsi,kubernetes.io/arch=amd64,kubernetes.io/hostname=k8smaster,kubernetes.io/os=linux,node-role.kubernetes.io/master=
   neunode1    Ready    <none>   43h   v1.18.6   beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,disktype=ssd,kubernetes.io/arch=amd64,kubernetes.io/hostname=neunode1,kubernetes.io/os=linux,type=node1,zone=node1
   ```

   上面输出可以看出，neunode1节点包含disktype=ssd标签。

3. 创建pod配置文件pod.yaml。该配置文件包含个节点选择器disktype:ssd。这意味着这个pod将调度到含有type=node1标签的节点。

   ```yaml
   apiVersion: v1
   kind: Pod
   metadata:
     name: busybox12
     namespace: default
   spec:
     nodeSelector:
       type: node1
     containers:
     - name: busybox12
       image: busybox
       command: ["sleep"]
       args: ["1000"]
   ```

4. 使用该配置文件进行部署

   ~~~
   kubectl create -f pod.yaml
   ~~~


### 强制约束Pod调度到指定Node节点上

~~~
Pod.spec.nodeName
~~~

1. 创建pod配置文件pod.yaml。该配置文件包含nodeName: k8smaster。这意味着这个pod将调度到k8smaster节点上。

   ```yaml
   apiVersion: v1
   kind: Pod
   metadata:
     name: busybox13
     namespace: default
   spec:
     nodeName: k8smaster
     containers:
     - name: busybox13
       image: busybox
       command: ["sleep"]
       args: ["1000"]
   ```

2. 使用该配置文件进行部署

   ~~~
   kubectl create -f pod.yaml
   ~~~

   

**参考：**https://www.cnblogs.com/wucaiyun1/p/11698320.html