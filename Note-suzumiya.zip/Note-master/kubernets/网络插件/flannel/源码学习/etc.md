/coreos/etcd/client/keys.go  

```
//NewKeysAPI构建与etcd的键值交互的KeysAPI通过HTTP的API。

func NewKeysAPI(c Client) KeysAPI 

//NewKeysAPIWithPrefix的作用类似于NewKeysAPI，但允许调用方提供自定义的基本URL路径。这应该只在非常罕见的情况下使用。 

func NewKeysAPIWithPrefix(c Client, p string) KeysAPI
```



/subnet/etcdv2/registry.go

~~~
//该函数调用client().Get()发送http请求到etcd获取数据,这里采用的是代码方式，其实我们完全可以通过curl或者postman发送http请求到etcd中
func (esr *etcdSubnetRegistry) getNetworkConfig(ctx context.Context)
~~~

