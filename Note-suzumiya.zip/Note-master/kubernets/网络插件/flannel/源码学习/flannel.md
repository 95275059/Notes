# main（）

etcd-endpoints：连接etcd地址
etcd-prefix ：在etcd里面路径前缀
iface：主机间流量互通的网卡

subnet-file：生成docker网络信息的路径
subnet-lease-renew-margin：这个是自网段的租约时间
ip-masq：是否启动ipmasq，就是SANT





LookupExtIface检查网卡是否存在，并且返回外部接口信息

~~~
&backend.ExternalInterface{
        Iface:     iface,
        IfaceAddr: ifaceAddr,
        ExtAddr:   extAddr,
    }
~~~

Iface是制定的外网端口，如果publicip没有制定，IfaceAddr等于ExtAddr。





