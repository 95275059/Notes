# 手动编译网络插件

1. 下载CNI插件，直接使用go get命令

   ~~~shell
   go get 	github.com/containernetworking/plugins
   ~~~

2. 进入$GOPATH/src/github.com/containernetworking/plugins项目文件夹，选择要编译测试的网络插件，如这里要对bridge网络插件进行编译，则进入bridge文件夹。

   ~~~bash
   # cd $GOPATH/src/github.com/containernetworking/plugins/plugins/main/bridge
   #pwd
   bridge.go  bridge_suite_test.go  bridge_test.go  README.md
   ~~~

3. 导入环境

   ~~~bash
   export GOFLAGS=-mod=vendor
   ~~~

4. 使用go build命令对该文件夹进行编译，或者对该文件夹下的文件进行编译，-o指定编译完生成的文件所在的文件夹。其中，/root/go/src/github.com/containernetworking/plugins/bin/bridge为指定编译后生产的文件， ./bridge.go 为需要进编译的文件

   ~~~bash
   go build -o /root/go/src/github.com/containernetworking/plugins/bin/bridge ./bridge.go 
   ~~~

5. 生成的/root/go/src/github.com/containernetworking/plugins/bin/bridge，就是可以进行使用的cni插件。