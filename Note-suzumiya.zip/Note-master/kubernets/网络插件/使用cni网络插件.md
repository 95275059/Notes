# 使用cni网络插件

1. 下载CNI插件，直接使用go get命令

   ~~~shell
   go get 	github.com/containernetworking/plugins
   ~~~

2. 构建cni组件

   ~~~shell
   cd $GOPATH/src/github.com/containernetworking/plugins
   ./build_linux.sh
   ~~~

   运行结束后，会在$GOPATH/src/github.com/containernetworking/plugins/项目文件夹下生成一个bin/文件夹，该文件夹下是生产的cni网络插件。

3. 将生成的cni组件放到/opt/cni/bin目录下，该目录是kubenetes调用cni插件，cni插件所在的目录。

4. 在/etc/cni/net.d中增加cni的配置文件，/etc/cni/net.d/中存放的是cni插件的配置文件

   ~~~shell
   $ mkdir -p /etc/cni/net.d
   $ cat >/etc/cni/net.d/10-mynet.conf <<EOF
   {
   	"cniVersion": "0.2.0",
   	"name": "mynet",
   	"type": "bridge",
   	"bridge": "cni0",
   	"isGateway": true,
   	"ipMasq": true,
   	"ipam": {
   		"type": "host-local",
   		"subnet": "10.22.0.0/16",
   		"routes": [
   			{ "dst": "0.0.0.0/0" }
   		]
   	}
   }
   EOF
   $ cat >/etc/cni/net.d/99-loopback.conf <<EOF
   {
   	"cniVersion": "0.2.0",
   	"name": "lo",
   	"type": "loopback"
   }
   EOF
   ~~~

5. 使用cni插件还需要如下配置。

   CentOS: 找到kubelet对应服务的配置文件目录，查看源文件并修改。

   ~~~
   vim /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf
   ~~~

   查看10-kubeadm.conf文件，内容为：（修改前）

   ~~~shell
   # Note: This dropin only works with kubeadm and kubelet v1.11+
   [Service]
   Environment="KUBELET_KUBECONFIG_ARGS=--bootstrap-kubeconfig=/etc/kubernetes/bootstrap-kubelet.conf --kubeconfig=/etc/kubernetes/kubelet.conf"
   Environment="KUBELET_CONFIG_ARGS=--config=/var/lib/kubelet/config.yaml"
   # This is a file that "kubeadm init" and "kubeadm join" generates at runtime, populating the KUBELET_KUBEADM_ARGS variable dynamically
   EnvironmentFile=-/var/lib/kubelet/kubeadm-flags.env
   # This is a file that the user can use for overrides of the kubelet args as a last resort. Preferably, the user should use
   # the .NodeRegistration.KubeletExtraArgs object in the configuration files instead. KUBELET_EXTRA_ARGS should be sourced from this file.
   EnvironmentFile=-/etc/sysconfig/kubelet
   ExecStart=
   ExecStart=/usr/bin/kubelet $KUBELET_KUBECONFIG_ARGS $KUBELET_CONFIG_ARGS $KUBELET_KUBEADM_ARGS $KUBELET_EXTRA_ARGS
   ~~~

   添加如下内容：

   ~~~SHELL
   Environment="KUBELET_NETWORK_ARGS=--network-plugin=cni --cni-conf-dir=/etc/cni/net.d --cni-bin-dir=/opt/cni/bin"
   ~~~

   添加完成后，10-kubeadm.conf内容为：

   ~~~shell
   # Note: This dropin only works with kubeadm and kubelet v1.11+
   [Service]
   Environment="KUBELET_KUBECONFIG_ARGS=--bootstrap-kubeconfig=/etc/kubernetes/bootstrap-kubelet.conf --kubeconfig=/etc/kubernetes/kubelet.conf"
   Environment="KUBELET_CONFIG_ARGS=--config=/var/lib/kubelet/config.yaml"
   Environment="KUBELET_NETWORK_ARGS=--network-plugin=cni --cni-conf-dir=/etc/cni/net.d --cni-bin-dir=/opt/cni/bin"
   # This is a file that "kubeadm init" and "kubeadm join" generates at runtime, populating the KUBELET_KUBEADM_ARGS variable dynamically
   EnvironmentFile=-/var/lib/kubelet/kubeadm-flags.env
   # This is a file that the user can use for overrides of the kubelet args as a last resort. Preferably, the user should use
   # the .NodeRegistration.KubeletExtraArgs object in the configuration files instead. KUBELET_EXTRA_ARGS should be sourced from this file.
   EnvironmentFile=-/etc/sysconfig/kubelet
   ExecStart=
   ExecStart=/usr/bin/kubelet $KUBELET_KUBECONFIG_ARGS $KUBELET_CONFIG_ARGS $KUBELET_KUBEADM_ARGS $KUBELET_EXTRA_ARGS
   ~~~

6. 重新载入配置文件并重启

   ~~~
   systemctl daemon-reload
   systemctl restart kubelet
   ~~~

7. 查看节点状态，pod状态

   ![1595229781257](1595229781257.png)

   如图表示插件安装使用成功。

   

参考：https://github.com/containernetworking/cni

​	[https://sealyun.com/blog/cni.html#%E7%8E%AF%E5%A2%83%E4%BB%8B%E7%BB%8D](https://sealyun.com/blog/cni.html#环境介绍)

​	https://blog.csdn.net/qq_36183935/article/details/90735049

https://blog.csdn.net/champly/article/details/97641999