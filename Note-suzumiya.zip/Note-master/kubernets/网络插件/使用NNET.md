# 使用NNET

## 导入项目文件及依赖

* 导入NNET项目文件

* 安装go语言中mysql库依赖

  ~~~
  go get  github.com/go-sql-driver/mysql
  ~~~

* 安装cobra，命令行依赖库

  ~~~
  go get -u github.com/spf13/cobra/cobra
  ~~~

  安装cobra会出现以下错误

  ~~~
  #go get  github.com/spf13/cobra/cobra  
  
  unrecognized import path "golang.org/x/sys/unix": https fetch: Get "https://golang.org/x/sys/unix?go-get=1": dial tcp 216.239.37.1:443: i/o timeout
  unrecognized import path "golang.org/x/text/transform": https fetch: Get "https://golang.org/x/text/transform?go-get=1": dial tcp 216.239.37.1:443: i/o timeout
  unrecognized import path "golang.org/x/text/unicode/norm": https fetch: Get "https://golang.org/x/text/unicode/norm?go-get=1": dial tcp 216.239.37.1:443: i/o timeout
  ~~~

  解决方法

  ~~~
  进入gopath的src目录：
  cd ~/go/src
  
  创建目录：
  mkdir -p  golang.org/x/
  
  进入刚创建的目录：
  cd golang.org/x
  
  克隆git库：
  git clone https://github.com/golang/sys.git
  git clone https://github.com/golang/text.git
  ~~~

* 安装zap，日志依赖库

  ~~~
  go get -u go.uber.org/zap
  ~~~

## 编译

### 编译kubenetctl命令行文件

1. 配置编译环境

   ~~~
   export GOFLAGS=-mod=vendor
   ~~~

2. 进入NNET项目文件夹

3. 将编译后的文件放在/bin/文件夹下

   ~~~
   go build -o /bin/kubenetctl ./kubenetctl
   ~~~

4. 如果将编译后的文件放在$GOPATH/bin文件夹下，还需要进行以下操作。

   ~~~
   go build -o /root/go/bin/kubenetctl ./kubenetctl
   ~~~

   将编译后的可执行文件添加到系统PATH中

   **root用户**

   ~~~
   # vim /root/.bash_profile
   export PATH=$PATH:$GOROOT/bin:$GOPATH/bin
   ~~~

   使得配置文件生效

   ~~~
   source /root/.bash_profile
   ~~~

   **普通用户，如ubuntu 用户**

   ~~~
   vim /home/ubuntu/.bash_profile
   export PATH=$PATH:$GOROOT/bin:$GOPATH/bin
   ~~~

   使得配置文件生效

   ~~~
   source /root/.bash_profile
   ~~~


### 编译网络插件

1. 配置编译环境

   ~~~
   export GOFLAGS=-mod=vendor
   ~~~

2. 进入NNET项目文件夹

3. 编译网络插件相关文件，将编译后的文件存放在/opt/cni/bin中

   ~~~
   go build -o /opt/cni/bin/brnet ./nnet.go
   ~~~

4. 在/etc/cni/net.d中更新cni配置文件

   ~~~
   mkdir -p /etc/cni/net.d
   cd /etc/cni/net.d
   
   cat > mybridge.conf <<"EOF"
   {
       "cniVersion": "0.2.0",
       "name": "mybridge",
       "type": "brnet",
       "brintname": "br-int",
       "bindid": "k8smaster",
       "mtu": 1500
   }
   EOF
   ~~~

   

5. 使用cni插件还需要如下配置。

   CentOS: 找到kubelet对应服务的配置文件目录，查看源文件并修改。

   ```
   vim /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf
   ```

   查看10-kubeadm.conf文件，内容为：（修改前）

   ```shell
   # Note: This dropin only works with kubeadm and kubelet v1.11+
   [Service]
   Environment="KUBELET_KUBECONFIG_ARGS=--bootstrap-kubeconfig=/etc/kubernetes/bootstrap-kubelet.conf --kubeconfig=/etc/kubernetes/kubelet.conf"
   Environment="KUBELET_CONFIG_ARGS=--config=/var/lib/kubelet/config.yaml"
   # This is a file that "kubeadm init" and "kubeadm join" generates at runtime, populating the KUBELET_KUBEADM_ARGS variable dynamically
   EnvironmentFile=-/var/lib/kubelet/kubeadm-flags.env
   # This is a file that the user can use for overrides of the kubelet args as a last resort. Preferably, the user should use
   # the .NodeRegistration.KubeletExtraArgs object in the configuration files instead. KUBELET_EXTRA_ARGS should be sourced from this file.
   EnvironmentFile=-/etc/sysconfig/kubelet
   ExecStart=
   ExecStart=/usr/bin/kubelet $KUBELET_KUBECONFIG_ARGS $KUBELET_CONFIG_ARGS $KUBELET_KUBEADM_ARGS $KUBELET_EXTRA_ARGS
   ```

   添加如下内容：

   ```SHELL
   Environment="KUBELET_NETWORK_ARGS=--network-plugin=cni --cni-conf-dir=/etc/cni/net.d --cni-bin-dir=/opt/cni/bin"
   ```

   添加完成后，10-kubeadm.conf内容为：

   ```shell
   # Note: This dropin only works with kubeadm and kubelet v1.11+
   [Service]
   Environment="KUBELET_KUBECONFIG_ARGS=--bootstrap-kubeconfig=/etc/kubernetes/bootstrap-kubelet.conf --kubeconfig=/etc/kubernetes/kubelet.conf"
   Environment="KUBELET_CONFIG_ARGS=--config=/var/lib/kubelet/config.yaml"
   Environment="KUBELET_NETWORK_ARGS=--network-plugin=cni --cni-conf-dir=/etc/cni/net.d --cni-bin-dir=/opt/cni/bin"
   # This is a file that "kubeadm init" and "kubeadm join" generates at runtime, populating the KUBELET_KUBEADM_ARGS variable dynamically
   EnvironmentFile=-/var/lib/kubelet/kubeadm-flags.env
   # This is a file that the user can use for overrides of the kubelet args as a last resort. Preferably, the user should use
   # the .NodeRegistration.KubeletExtraArgs object in the configuration files instead. KUBELET_EXTRA_ARGS should be sourced from this file.
   EnvironmentFile=-/etc/sysconfig/kubelet
   ExecStart=
   ExecStart=/usr/bin/kubelet $KUBELET_KUBECONFIG_ARGS $KUBELET_CONFIG_ARGS $KUBELET_KUBEADM_ARGS $KUBELET_EXTRA_ARGS
   ```

6. 重新载入配置文件并重启

   ```
   systemctl daemon-reload
   systemctl restart kubelet
   ```

### 创建日志文件夹

~~~
mkdir /var/log/NNET/
~~~

## 创建数据库

创建kubenet用户

创建数据库

~~~
CREATE DATABASE kubeNET;
~~~

创建pod数据表

~~~
CREATE TABLE IF NOT EXISTS `pod`(
   `podname` VARCHAR(40) NOT NULL,
   `podip` VARCHAR(40) NOT NULL,
   `netcidr` VARCHAR(40) NOT NULL,
   `netname` VARCHAR(40) NOT NULL,
   PRIMARY KEY ( `podname` )
)ENGINE=InnoDB DEFAULT CHARSET=utf8;
~~~

创建network数据表

~~~
CREATE TABLE IF NOT EXISTS `network`(
   `netcidr` VARCHAR(40) NOT NULL,
   `netname` VARCHAR(40) NOT NULL,
   `netid` VARCHAR(60) NOT NULL,
   `subnetid` VARCHAR(60) NOT NULL,
   `connectnet` VARCHAR(10000) NOT NULL,
   PRIMARY KEY ( `netcidr` )
)ENGINE=InnoDB DEFAULT CHARSET=utf8;
~~~

### 删除数据库

清除pod和network数据库

~~~
 truncate table pod;
 truncate table network;
~~~





## 运行测试

下载busybox镜像

~~~
docker pull busybox
~~~



~~~
kubenetctl base "kubectl run busybox8 --rm=true --image=busybox --restart=Never -it" --name busybox8 --ip 2.4.4.10 --network 2.4.0.0/16 
~~~

~~~
kubenetctl base "kubectl run busybox3 --rm=true --image=busybox --restart=Never -it" --name busybox3 --ip 2.4.1.103 --network 2.4.0.0/16 

kubenetctl base "kubectl run busybox1 --rm=true --image=busybox --restart=Never -it" --name busybox1 --ip 2.4.1.10 --network 2.4.0.0/16 
~~~

~~~
kubectl exec -ti busybox1  -n default  -- /bin/sh
~~~

删除数据库中的某条信息

~~~
delete from pod where podname="busybox1"
~~~

清空数据表

~~~
 truncate table pod;
~~~



使用配置文件创建pod

~~~
 kubectl  create -f busybox10.yaml
~~~

添加节点标签

~~~
kubectl label node computer disktype=ssd
~~~

查看节点标签

~~~
kubectl get  node --show-labels
~~~

