学习《每天五分钟玩转Kubernetes》第30页，Deployment配置文件简介， 按照书上写配置文件如下：

~~~
apiVersion: extensions/v1bata1
kind: Deployment
metadata:
  name: nginx-deployment
spec:
  selector:
    matchLabels:
      app: nginx
  replicas: 1
  template:
    metadata:
      labels:
        app: web_server
    spec:
      containers:
      - name: nginx
        image: nginx:1.7.9
~~~

运行报错

~~~
ubuntu@master:~$ kubectl apply -f nginx.yml 
error: unable to recognize "nginx.yml": no matches for kind "Deployment" in version "extesions/v1beta1"
~~~

解决问题：

在Kubernetes 1.16中`api`已进行了一些更改。

您可以使用以下命令检查哪些API支持当前的Kubernetes对象

~~~
ubuntu@master:~$ kubectl api-resources | grep deployment
deployments                       deploy       apps                           true         Deployment
~~~

这意味着只有apiVersion选用apps才是正确的部署选项（extensions 不支持Deployment）。使用StatefulSet的情况相同。你只需要将Deployment 和StatefuSet 的apiVersion 改为apiVersion：apps/v1.

除此之外，下图中标出的地方的名称都应该一致。

![](.\微信图片_20191030145133.png)

正确的写法如下：

~~~
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-nginx
spec:
  selector:
    matchLabels:
      app: my-nginx
  replicas: 2
  template:
    metadata:
      labels:
        app: my-nginx
    spec:
      containers:
      - name: my-nginx
        image: nginx
        ports:
        - containerPort: 80
~~~

以下是几种遇到的错误

* 直接不写spec.mathlabels创建直接报错缺少缺少必要字段selector

  ~~~
  apiVersion: apps/v1
  kind: Deployment
  metadata:
    name: my-nginx
  spec:
    replicas: 2
    template:
      metadata:
        labels:
          run: my-nginx
      spec:
        containers:
        - name: my-nginx
          image: nginx
          ports:
          - containerPort: 80
  ~~~

  运行报错

  ~~~
  error: error validating "nginx.yml": error validating data: ValidationError(Deployment.spec): missing required field "selector" in io.k8s.api.apps.v1.DeploymentSpec; if you choose to ignore these errors, turn validation off with --validate=false
  ~~~

  

* 当把matchLables匹配的和下面pod模板不相对应,也会直接报错,选择的和模板标签不匹配

  ~~~
  apiVersion: apps/v1
  kind: Deployment
  metadata:
    name: my-nginx
  spec:
    selector:
      matchLabels:
        app: my-nginx-add
    replicas: 2
    template:
      metadata:
        labels:
          app: my-nginx
      spec:
        containers:
        - name: my-nginx
          image: nginx:1.14
          ports:
          - containerPort: 80
  ~~~

  运行报错

  ~~~
  The Deployment "my-nginx" is invalid: spec.template.metadata.labels: Invalid value: map[string]string{"app":"my-nginx"}: `selector` does not match template `labels`
  ~~~

查看帮助手册

~~~
 kubectl explain Deployment.spec

    selector  <Object>
     Label selector for pods. Existing ReplicaSets whose pods are selected by
     this will be the ones affected by this deployment.

     pod的标签选择器。 由此选择其pod的现有ReplicaSet(副本集)将受此部署影响的副本。
~~~



总结：

1. 在Deployment中必须写matchLables,
2. 在定义模板的时候必须定义labels,因为Deployment.spec.selector是必须字段,而他又必须和template.labels对应,
3. template里面定义的内容会应用到下面所有的副本集里面,在template.spec.containers里面不能定义labels标签.

**参考：**

https://blog.51cto.com/13447608/2353863

https://stackoverflow.com/questions/58481850/no-matches-for-kind-deployment-in-version-extensions-v1beta1#