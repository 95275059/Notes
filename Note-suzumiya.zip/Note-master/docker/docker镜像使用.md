# Docker 镜像使用

## 列出镜像列表

~~~
docker images
~~~

![1597387689543](1597387689543.png)

>各个选项说明:
>
>- **REPOSITORY：**表示镜像的仓库源
>- **TAG：**镜像的标签
>- **IMAGE ID：**镜像ID
>- **CREATED：**镜像创建时间
>- **SIZE：**镜像大小

同一仓库源可以有多个 TAG，代表这个仓库源的不同个版本，如 ubuntu 仓库源里，有 15.10、14.04 等多个不同的版本，我们使用 REPOSITORY:TAG 来定义不同的镜像。

如果要使用版本为15.10的ubuntu系统镜像来运行容器时，命令如下：

~~~
docker run -t -i ubuntu:15.10 /bin/bash 
~~~

>参数说明：
>
>- **-i**: 交互式操作。
>- **-t**: 终端。
>- **ubuntu:15.10**: 这是指用 ubuntu 15.10 版本镜像为基础来启动容器。
>- **/bin/bash**：放在镜像名后的是命令，这里我们希望有个交互式 Shell，因此用的是 /bin/bash。

如果要使用版本为 14.04 的 ubuntu 系统镜像来运行容器时，命令如下：

~~~shell
docker run -t -i ubuntu:14.04 /bin/bash 
~~~

**如果你不指定一个镜像的版本标签，例如你只使用 ubuntu，docker 将默认使用 ubuntu:latest 镜像。**

## 获取一个新的镜像

当我们在本地主机上使用一个不存在的镜像时 Docker 就会自动下载这个镜像。如果我们想预先下载这个镜像，我们可以使用 docker pull 命令来下载它。

~~~
docker pull ubuntu:13.10
~~~

### 查找镜像

我们可以从 Docker Hub 网站来搜索镜像，Docker Hub 网址为： **https://hub.docker.com/**

我们也可以使用 docker search 命令来搜索镜像。比如我们需要一个 httpd 的镜像来作为我们的 web 服务。我们可以通过 docker search 命令搜索 httpd 来寻找适合我们的镜像。

~~~
docker search httpd
~~~

![img](https://www.runoob.com/wp-content/uploads/2016/05/423F2A2C-287A-4B03-855E-6A78E125B346.jpg)

>**NAME:** 镜像仓库源的名称
>
>**DESCRIPTION:** 镜像的描述
>
>**OFFICIAL:** 是否 docker 官方发布
>
>**stars:** 类似 Github 里面的 star，表示点赞、喜欢的意思。
>
>**AUTOMATED:** 自动构建。

### 拖取镜像

使用命令 docker pull 来下载镜像.

~~~
docker pull httpd
~~~

## 删除镜像

使用 docker rmi 命令

~~~
 docker rmi hello-world
~~~

## 创建镜像

当我们从 docker 镜像仓库中下载的镜像不能满足我们的需求时，我们可以通过以下两种方式对镜像进行更改。

- 1、从已经创建的容器中更新镜像，并且提交这个镜像
- 2、使用 Dockerfile 指令来创建一个新的镜像

###  更新镜像

更新镜像之前，我们需要使用镜像来创建一个容器

```
 docker run -it ubuntu /bin/sh
```

在运行的容器内使用 **apt-get update** 命令进行更新 ,并安装iputils-ping，net-tools

在完成操作之后，输入 exit 命令来退出这个容器。

可以通过命令 docker commit 来提交容器副本。

~~~
[root@k8smaster ~]# docker commit -m="update" -a="sjy" 1079f10bf242 ubuntu:ping 
sha256:6307c5bd87cd7a18cc0649f3120068097377f2420790e6406bee28ce18c5667e
~~~

>- **-m:** 提交的描述信息
>- **-a:** 指定镜像作者
>- **e218edb10161：**容器 ID
>- **runoob/ubuntu:v2:** 指定要创建的目标镜像名

可以使用 **docker images** 命令来查看的新镜像 

~~~
docker images
~~~

![1597389506961](1597389506961.png)

~~~
[root@k8smaster ~]# docker run -t -i ubuntu:ping /bin/bash
root@87c6592a5102:/# 
~~~

### 构建镜像

使用命令 **docker build** ， 从零开始来创建一个新的镜像。为此，我们需要创建一个 Dockerfile 文件，其中包含一组指令来告诉 Docker 如何构建我们的镜像。

~~~
vim Dockerfile

FROM ubuntu
RUN apt-get update && apt-get install -y iputils-ping
~~~

每一个指令都会在镜像上创建一个新的层，每一个指令的前缀都必须是大写的。

第一条FROM，指定使用哪个镜像源

RUN 指令告诉docker 在镜像内执行命令，安装了什么

通过 docker build 命令来构建一个镜像

~~~
[root@k8smaster dockerfile]#docker build -t centos:test .
Sending build context to Docker daemon  2.048kB
Step 1/2 : FROM ubuntu
 ---> 1e4467b07108
Step 2/2 : RUN apt-get update && apt-get install -y iputils-ping
 ---> Running in 5e0ea1cfca6c
 ......
debconf: falling back to frontend: Teletype
Setting up iputils-ping (3:20190709-3) ...
Processing triggers for libc-bin (2.31-0ubuntu9) ...
Removing intermediate container 5e0ea1cfca6c
 ---> bacdfa81c1d3
Successfully built bacdfa81c1d3
Successfully tagged centos:test
~~~

>- **-t** ：指定要创建的目标镜像名
>- **.** ：Dockerfile 文件所在目录，可以指定Dockerfile 的绝对路径

使用docker images 查看创建的镜像已经在列表中存在

![1597393756008](1597393756008.png)

我们可以使用新的镜像来创建容器

~~~
docker run -t -i centos:test  /bin/bash
~~~

