# Socket编程

创建服务端和客户端，实现客户端一直接收消息的同时，可以发送消息。对客户端使用多线程处理。

*注意：threading.Thread(target=inputmsg)写法，target对应的函数，不应该有（）*

Ser.py

~~~python
import socket
import time

HOST = '127.0.0.1'
PORT = 35267
BUFSIZ = 1024
ADDR = (HOST,PORT)

Sersocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
Sersocket.bind(ADDR)
Sersocket.listen(5)

while True:
    print('Waiting for connection...')
    clisocket,cliaddr = Sersocket.accept()
    print('connected from : ',cliaddr)
    msg = 'Welcome to '
    clisocket.send(msg.encode())

    while True:
        clidata = clisocket.recv(BUFSIZ)
        if not clidata:
            break
        print('cli:',clidata.decode())

        msg = time.ctime()+'ser had recieved'
        time.sleep(4)
        clisocket.send(msg.encode())
~~~

Cli.py

```python
import socket
import threading
import time
HOST = '127.0.0.1'
PORT = 35267
BUFSIZ = 1024
ADDR =(HOST,PORT)


clisocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
clisocket.connect(ADDR)


def inputmsg():
    while True:
        data = input('>')
        clisocket.send(data.encode())

def recvieve():
   while True:
        serdata = clisocket.recv(BUFSIZ)
        print('ser:',serdata.decode())


i = threading.Thread(target=inputmsg)
i.setDaemon(True)
r = threading.Thread(target=recvieve)
r.setDaemon(True)

r.start()
i.start()

while True:
    time.sleep(5)
```



Cli.py的最后while循环是为了保证主进程没有结束，因为i和r已经设置为守护进程。如果i和r没有设置为守护进程，最后while循环可以去掉。