# 开启IP转发功能

linux发行版默认情况下是不开启ip转发功能的。这是一个好的做法，因为大多数人是用不到ip转发的，但是如果我们架设一个linux路由或者vpn服务我们就需要开启该服务了。

**查看是否开启**

以下两种方法查看是否开启ip转发功能

1. 我们需要通过访问sysctl的内核ipv4.ip_forward来判断转发是否开启。

   ~~~
   #sysctl net.ipv4.ip_forward
   #若net.ipv4.ip_forward = 0，则代表未开启转发功能
   net.ipv4.ip_forward = 0
   ~~~

2. ~~~
   #cat /proc/sys/net/ipv4/ip_forward
   #若输出为0，则代表未开启
   0
   ~~~

**开启转发**

1. 暂时生效，无需重启。这种设置只是暂时的; 它的效果会随着计算机的重启而失效。

   ~~~
   sysctl -w net.ipv4.ip_forward=1
   ~~~

   或

   ~~~
   echo 1 > /proc/sys/net/ipv4/ip_forward
   ~~~

2. 永久生效。修改/etc/sysctl.conf，增加一条 net.ipv4.ip_forward = 1

   ~~~
   #vim /etc/sysctl.conf
   
   net.ipv4.ip_forward = 1
   ~~~

   使得命令生效

   ~~~
   sysctl -p /etc/sysctl.conf
   ~~~

   ubuntu使用

   ~~~
   /etc/init.d/procps.sh restart
   ~~~

   



