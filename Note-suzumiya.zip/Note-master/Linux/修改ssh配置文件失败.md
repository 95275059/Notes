# 修改配置文件失败

1. 制作镜像，安装ssh服务，修改ssh配置文件/etc/ssh/sshd_config ，将PasswordAuthentication修改为 yes。

2. 在openstack云平台上使用步骤1中制作的镜像创建虚拟机，开机后发现/etc/ssh/sshd_config 中的PasswordAuthentication 仍未no，无法使用ssh进行登录。
3. 制作多次镜像，仍然这样，寻找原因未果。

## 解决方法

制作镜像时修改  /etc/cloud/cloud.cfg 

~~~shell
vim /etc/cloud/cloud.cfg

# 修改如下内容
disable_root: 0  # 将此选项改为0，表示不禁止使用root登录
ssh_pwauth:	  1  # 将此选项改为1，表示允许ssh使用密码认证
~~~

