# 修改/etc/resolv.conf

 修改 /etc/NetworkManager/NetworkManager.conf 文件，在main部分添加 “dns=none” 选项：

~~~
[main]

plugins=ifcfg-rh

dns=none
~~~

NetworkManager重新装载上面修改的配置

~~~
# systemctl restart NetworkManager.service
~~~

手工修改 /etc/resolv.conf

~~~
nameserver 114.114.114.114

nameserver 8.8.8.8
~~~

