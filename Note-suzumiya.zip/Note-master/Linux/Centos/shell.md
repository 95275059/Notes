## 在变量的设置当中，单引号与双引号的用途有何不同？

单引号与双引号的最大不同在于双引号仍然可以保有变量的内容，但单引号内仅能是一般字符 ，而不会有特殊符号。 我们以底下的例子做说明：假设您定义了一个变量name=VBird ，现在想以 name 这个变量的内容定义出 myname 显示 VBird its me 这个内容，要如何设置呢？

~~~shell
[root@www ~]# name=VBird
[root@www ~]# echo $name
VBird
[root@www ~]# myname="$name its me"
[root@www ~]# echo $myname
VBird its me
[root@www ~]# myname='$name its me'
[root@www ~]# echo $myname
$name its me
~~~

使用了单引号的时候，那么 $name 将失去原有的变量内容，仅为一般字符的显示类型而已！



## 查看链接数

~~~
netstat -n| grep 21 |  grep  ^tcp|awk '{print $NF}'|sort -nr|uniq -c
~~~

21为要查看的端口号

~~~
netstat -n | awk '/^tcp/ {++S[$NF]} END {for(a in S) print a, S[a]}'
~~~



lsof -i :21

## ip或其他条目过多

~~~shell
ip addr | more
~~~

~~~
ip addr | less
~~~



# 对比文件

vimdiff 使用

~~~shell
# vimdiff  FILE_LEFT  FILE_RIGHT

或者

# vim -d  FILE_LEFT  FILE_RIGHT
~~~

运行结果：屏幕被垂直分割，左右两侧分别显示被比较的两个文件。两个文件中连续的相同的行被折叠了起来，以便使用者能把注意力集中在两个文件的差异上。只在某一文件中存在的行的背景色被设置为<font color=blue >蓝色</font>，而在另一文件中的对应位置被显示为<font color=green >绿色</font>。两个文件中都存在，但是包含差异的行显示为<font color=pink >粉色</font>背景，引起差异的文字用<font color=red >红色</font>背景加以突出。

# 重启网卡服务

~~~
service  networking restart
~~~

