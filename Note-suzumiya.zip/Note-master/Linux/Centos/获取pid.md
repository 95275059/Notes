查询进程pid

```
ps aux | grep redis | grep -v "grep" | tr -s ' '| cut -d ' ' -f 2
```

结束查询进程

~~~
kill $(ps aux | grep pychat_server.py | grep -v "grep" | tr -s ' '| cut -d ' ' -f 2)
~~~

