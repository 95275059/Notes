# iperf

**注意：使用的是iperf3还是iperf**



Iperf是一个网络性能测试工具。Iperf可以测试TCP和UDP带宽质量。Iperf可以测量最大TCP带宽，具有多种参数和UDP特性。 Iperf可以报告带宽，延迟抖动和数据包丢失。利用Iperf这一特性，可以用来测试一些网络设备如路由器，防火墙，交换机等的性能。

Iperf的主要功能如下：

**TCP**

- 测量网络带宽
- 报告MSS/MTU值的大小和观测值
- 支持TCP窗口值通过套接字缓冲
- 当P线程或Win32线程可用时，支持多线程。客户端与服务端支持同时多重连接

**UDP**

- 客户端可以创建指定带宽的UDP流
- 测量丢包
- 测量延迟
- 支持多播
- 当P线程可用时，支持多线程。客户端与服务端支持同时多重连接（不支持Windows）

**其他**

- 在适当的地方，选项中可以使用K（kilo-）和M（mega-）。例如131072字节可以用128K代替。
- 可以指定运行的总时间，甚至可以设置传输的数据总量。
- 在报告中，为数据选用最合适的单位。
- 服务器支持多重连接，而不是等待一个单线程测试。
- 在指定时间间隔重复显示网络带宽，波动和丢包情况。
- 服务器端可作为后台程序运行。
- 服务器端可作为Windows 服务运行。
- 使用典型数据流来测试链接层压缩对于可用带宽的影响。
- 支持传送指定文件，可以定性和定量测试

## 安装iperf3

### ubuntu

~~~
apt-get install iperf3
~~~

## 使用方法

### TCP测试

**server**

server启动

~~~
iperf3 -s
~~~

或选择参数

~~~
# iperf3 -s -p 12345 -i 1
~~~

>-p：端口号
>
>-i：每次报告之间的时间间隔



**client**

~~~
# iperf3 -c 172.16.0.14 -p 12345 -i 1 -t 10
~~~

>-c：服务端的IP
>
>-p：端口号
>
>-t：传输的总时间
>
>-i：每次报告之间的时间间隔



### UDP测试

**server**

~~~shell
# iperf -u -s 
~~~

**client**

~~~shell
# iperf -u -c 10.32.0.254 -b 900M  -i 1  -w 1M  -t 60 
~~~

> -b表示 使用带宽数量，千兆链路使用90%容量进行测试就可以了。 



## 参数

**通用参数** 

-f  [k|m|K|M] 分别表示以Kbits, Mbits, KBytes, MBytes显示报告，默认以Mbits为单位，

eg:`iperf3 -c 222.35.11.23 -f K `

-i sec 以秒为单位显示报告间隔，eg:`iperf -c 222.35.11.23 -i 2`

-l 缓冲区大小，默认是8KB,eg:`iperf -c 222.35.11.23 -l 16`

-m 显示tcp最大mtu值 

-o 将报告和错误信息输出到文件,eg:`iperf -c 222.35.11.23 -o c:\iperflog.txt `

-p 指定服务器端使用的端口或客户端所连接的端口，eg:`iperf -s -p 9999;iperf -c 222.35.11.23 -p 9999 `

-u 使用udp协议 

-w 指定TCP窗口大小，默认是8KB 

-B 绑定一个主机地址或接口（当主机有多个地址或接口时使用该参数）

-C 兼容旧版本（当server端和client端版本不一样时使用）

-M 设定TCP数据包的最大mtu值

-N 设定TCP不延时

-V 传输ipv6数据包   server专用参数 

-D 以服务方式运行ipserf，eg:`iperf -s -D -R` 停止iperf服务，针对-D，eg:`iperf -s -R`  

**客户端专用参数**

-d 同时进行双向传输测试 

-n 指定传输的字节数，eg:`iperf -c 222.35.11.23 -n 100000`

-r 单独进行双向传输测试 

-t 测试时间，默认10秒,eg:`iperf -c 222.35.11.23 -t 5`

-F 指定需要传输的文件

-T 指定ttl值 



* 参考网站：<https://www.cnblogs.com/yingsong/p/5682080.html>

  ​					<https://www.cnblogs.com/winifred-tang94/p/5877662.html>

  ​					<https://blog.csdn.net/peijian1998/article/details/26563957/>