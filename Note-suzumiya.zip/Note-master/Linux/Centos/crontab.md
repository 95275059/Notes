# crontab

  使用crontab你可以在指定的时间执行一个shell脚本或者一系列Linux命令。例如系统管理员安排一个备份任务使其每天都运行,本次使用crontab定时启动一个python脚本文件。

以下为crontab命令格式

![733392-20180530112549735-793099971](.\733392-20180530112549735-793099971.png)

crontab [-u user] file
crontab [ -u user ] [ -i ] { -e | -l | -r }

- -u user：用于设定某个用户的crontab服务；
- file: file为命令文件名，表示将file作为crontab的任务列表文件并载入crontab；
- -e：编辑某个用户的crontab文件内容，如不指定用户则表示当前用户；
- -l：显示某个用户的crontab文件内容，如不指定用户则表示当前用户；
- -r：从/var/spool/cron目录中删除某个用户的crontab文件。
- -i：在删除用户的crontab文件时给确认提示。

**crontab注意点**

1. crontab有2种编辑方式：直接编辑/etc/crontab文件与crontab –e，其中/etc/crontab里的计划任务是系统中的计划任务，而用户的计划任务需要通过crontab –e来编辑；
2. 每次编辑完某个用户的cron设置后，cron自动在/var/spool/cron下生成一个与此用户同名的文件，此用户的cron信息都记录在这个文件中，这个文件是不可以直接编辑的，只可以用crontab -e 来编辑。
3. crontab中的command尽量使用<font color=red>绝对路径</font>，否则会经常因为路径错误导致任务无法执行。
4. 新创建的cron job不会马上执行，至少要等2分钟才能执行，可从起cron来立即执行。
5. %在crontab文件中表示“换行”，因此假如脚本或命令含有%,需要使用\%来进行转义。

# 使用crontab定时启动python脚本

使用crontab 每隔一小时运行一次python脚本

python脚本control.py如下

~~~python
import os

def kill_process():
    os.system("kill $(ps aux | grep pychat_server.py | grep -v 'grep' | tr -s ' '| cut -d ' ' -f 2)")

def start_process():
    os.system('/usr/local/bin/python3 /home/centos/UserAction/chat_p2p/pychat_server.py')

kill_process()
start_process()
~~~

该脚本结束pychat_server.py运行之后，在重新运行pychat_server.py。

**注意： 使用crontab时，除了crontab -e命令需要绝对路径(包括python运行环境)，执行的python脚本中的文件路径，以及python命令等也需要是绝对路径，如上述脚本，文件位置：/home/centos/UserAction/chat_p2p/pychat_server.py ，python环境为：/usr/local/bin/python3。其中python脚本中的python运行路径要特别注意。**

1. 编写好python脚本
2.  crontab -e 进入编辑页面将命令语句加入到定时任务当中。此语句为每个小时运行一次control.py脚本。![微信图片编辑_20190806205414](.\微信图片编辑_20190806205414.jpg)

3. 重启服务，否则要至少要等2分钟才能执行

   ~~~
   service crond restart
   ~~~

4. 查看运行结果

   查看运行日志： /var/log/cron

   查看运行结果：/var/spool/mail/root

   ![微信图片编辑_20190807110655](.\微信图片编辑_20190807110655.jpg)

**注意**：相关路径一定要是绝对路径。

# crontab服务操作说明：

~~~
service crond start //启动服务
 
service crond stop //关闭服务
 
service crond restart //重启服务
 
service crond reload //重新载入配置
	
service crond status //查看服务状态
~~~



**参考**：https://www.cnblogs.com/ftl1012/p/crontab.html

​			https://www.cnblogs.com/phpstudy2015-6/p/7534968.html

​			https://www.cnblogs.com/yuwensong/p/10941973.html

​			https://blog.csdn.net/weixin_41594007/article/details/80636390

​			https://blog.csdn.net/liu0808/article/details/80668705