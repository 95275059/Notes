## 抓ping包

~~~
 tcpdump -i eth1 icmp 
~~~

在网卡1上监听ping包