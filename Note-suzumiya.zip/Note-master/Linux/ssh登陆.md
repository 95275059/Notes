# 使用SecureCRT无法远程登陆

创建Ubuntu 16.04 虚拟机 安装好ssh服务，root用户名和密码均正确，提示以下错误

> 使用SecureCRT登陆，提示
>
> The server has disconnected with an error.  Server message reads:
>
> A protocol error occurred. Change of username or service not allowed: (root,ssh-connection) -> (192.168.116.25,ssh-connection)

1. 首先，在 SecureCRT设置中的用户名和你登录时候输入的用户名不相符，在这里改一下就可以：

 		选项 -> 会话选项 -> 连接 -> SSH2 -> 用户名

![](.\微信图片编辑_20191008144531.jpg)

​	如图位置，将用户名修改为需要登陆的用户名，这里为root。

2. 在虚拟机内部修改ssh配置文件

   vi /etc/ssh/sshd_config 

   修改 PasswordAuthentication yes

   允许密码认证

   

   修改#PermitRootLogin no为PermitRootLogin yes 

   允许root认证登录

   

   重启服务：service sshd restart

   

   说明：sshd_config是ssh的配置文件，其中有一个选项 PermitRootLogin 用来配置是否允许root用户登录，默认的xxx-password表示不允许使用密码进行全登录认证，yes则是允许root登录。

