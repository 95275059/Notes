# 安装ssh服务

1. 安装ssh

   ~~~
   apt-get update
    
   apt-get install openssh-server
   ~~~

   

2. 启动ssh服务

   ~~~
   /etc/init.d/ssh start
   ~~~

   重启命令与关闭命令如下：

   ~~~
   /etc/init.d/ssh restart   #重启SSH服务
   /etc/init.d/ssh stop      #关闭SSH服务
   ~~~

3. 查看进程，检查是否启动成功，键入如下命令：

   ~~~
   ps -e | grep sshd
   ~~~

   ![](.\微信图片_20191027170753.png)

4. 配置root用户SSH服务。在/etc/ssh/sshd_config中，修改为“PermitRootLogin yes”

   

   