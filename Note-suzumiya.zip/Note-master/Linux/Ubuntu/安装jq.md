# 安装jq

~~~
apt-get install jq
~~~

