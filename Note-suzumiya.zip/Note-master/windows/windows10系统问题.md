* win10，在桌面点击右键：显示设置和个性化，出现“该文件没有与之关联的应用来执行该操作，请安装应用，若已经安装应用，请在默认应用设置页面中创建关联”错误。

  在右下方快捷栏中，选择网络图标，点击宽带连接或者网络连接，无法进入网络中心。

  ![](I:\MyNote\windows\微信图片编辑_20191011212950.jpg)

  ![](.\微信图片编辑_20191011213058.jpg)

  **解决方法：**

  1. WIN + R 打开运行，并输入 regedit，点击确定，进入注册表编辑器

  2. 找到HKEY_CURRENT_USER\Software\Classes\ms-settings,重命名ms-settings（图片中ms-settings1是我已经重命名过了）

     ![](.\微信图片编辑_20191011213806.jpg)

  

  **注：网上还有一种说法是，删除ms-settings文件，没有尝试**

  **参考：**https://www.cnblogs.com/web-yoyo/p/11145843.html

  ​			https://blog.csdn.net/tann888/article/details/94600573

  

  