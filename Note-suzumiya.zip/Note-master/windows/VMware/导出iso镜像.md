# VMware workstation 将虚拟机导出为iso镜像。

1. 将虚拟机关机

2. 选择文件→导出为ovf

3. 导出有四个文件，其中vmdk是虚拟机文件，iso是镜像文件

   ![](.\微信图片_20191031210058.png)

https://docs.openstack.org/image-guide/convert-images.html