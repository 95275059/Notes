# 控制节点

~~~
openstack token issue
~~~

