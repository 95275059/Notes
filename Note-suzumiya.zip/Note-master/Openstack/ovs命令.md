* 查看ovs

  ~~~
  ovs-vsctl show
  ~~~

* 删除端口

  ~~~
  ovs-vsctl del-port <网桥名> <端口名>
  ~~~

  

  ~~~
  ovs-vsctl del-port br-int qvo1201f875-ed
  ~~~

  