本次安装系统环境为ubuntu16.04.6，openstack为Q版（Queens）Neutron使用openvswitch

