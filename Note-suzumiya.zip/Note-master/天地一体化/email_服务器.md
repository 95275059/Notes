# 邮件服务器无法接收邮件

- Postfix配置文件为：vim /etc/postfix/main.cf

修改后的配置为，这样就不需要修改mynetworks，就可以直接进行邮件服务。

![1558406294169](C:\Users\Administrator\AppData\Roaming\Typora\typora-user-images\1558406294169.png)

mynetworks修改

```
mynetworks = 168.100.189.0/28, 127.0.0.0/8, 127.0.0.1,0.0.0.0/0
```

注意，该配置服务器虽然可以接收到邮件（应该不需要在mynetworks中添加相应网段），但是无法在/var/spool/mail/下的root或jslserver中查看部分接收到的邮件。如果想查看，可以参考下一条，在mynetworks中添加相应网段地址。

# 无法查看邮件

查看/var/spool/mail/下的root或jslserver，发现邮件无法更新，寻找配置问题，通过对比发现以下配置不同。

**Postfix配置**

Postfix配置文件：/etc/postfix/main.cf，main.cf注意以下几条配置

~~~shell
myhostname = mail.jslserver.novalocal
mydomain = jslserver.novalo

mydestination = $myhostname, localhost.$mydomain, localhost, $mydomain,
    mail.$mydomain, www.$mydomain, ftp.$mydomain,jslserver.novalocal
    
mynetworks = 168.100.189.0/28,71.1.0.0/16, 127.0.0.0/8, 127.0.0.1,71.0.0.0/16,192.168.0.0/24,192.168.203.0/24	
~~~

myhostname参数为邮件服务器地址，mydomain参数为域名;

注意mydestination，和mynetwork配置；

mynetworks中"71.1.0.0/16"为服务器所在网段，“71.0.0.0/16”为客户端所在网段，在网络环境发生变化的时候，注意修改相应的网段配置。

>记录另一台配置成功的，可以查看邮件的，main.cf文件中 mynetworks的配置
>
>~~~
>mynetworks = 168.100.189.0/28, 127.0.0.0/8,127.0.0.1,180.0.0.0/16,180.1.0.0/16,180.2.0.0/16,180.3.0.0/16,180.4.0.0/16,180.5.0.0
>/16,180.6.0.0/16,192.168.0.0/24,192.168.203.0/24
>~~~
>
>180.0.0.0/16 为服务器所在网段；
>
>180.1.0.0/16,180.2.0.0/16,180.3.0.0/16,180.4.0.0/16,180.5.0.0/16,180.6.0.0/16 为客户端所在网段。
>
>

**hosts文件配置**

hosts文件：/etc/hosts。可以在/var/spool/mail/查看邮件的情况（email行为成功），hosts配置为

~~~shell
127.0.0.1   localhost jslserver.novalocal mail.jslserver.novalocal localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6 jslserver.novalocal mail.jslserver.novalocal
~~~

>记录邮件服务成功的hosts文件配置如下：
>
>~~~shell
>127.0.0.1   localhost jslserver.novalocal mail.jslserver.novalocal localhost.localdomain localhost4 localhost4.localdomain4
>#180.0.0.43  localhost jslserver.novalocal mail.jslserver.novalocal
>#180.1.0.1  jslserver1.novalocal  mail.jslserver1.novalocal
>#180.2.0.1  jslcli2.novalocal  mail.jslcli2.novalocal
>#180.3.0.1  jslcli3.novalocal   mail.jslcli3.novalocal
>#180.4.0.1  jslcli4.novalocal   mail.jslcli4.novalocal
>#180.5.0.1  jslcli5.novalocal  mail.jslcli5.novalocal
>#180.6.0.1  jslcli6.novalocal  mail.jslcli6.novalocal
>::1         localhost localhost.localdomain localhost6 localhost6.localdomain6 jslserver.novalocal mail.jslserver.novalocal
>~~~
>
>mail.jslserver.novalocal与postfix配置文件/etc/postfix/main.cf里面的myhostname参数和mydomain参数一致，myhostname参数为邮件服务器地址，mydomain参数为域名。
>
>配置中的被#的部分目前还没有发现作用，先做记录保存
>
>

**hostname**

用户名修改 /etc/hostname

~~~
jslserver.novalocal
~~~

>目前还没有发现该配置是否影响邮件收发，先做记录。



# 服务器启动错误

进入配置页，发现

Error: Smarty template compile directory templates_c is not writable



解决方法

cd /var/www/html/postfixadmin

chmod -R 777 templates_c