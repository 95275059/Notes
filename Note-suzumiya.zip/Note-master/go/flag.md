# flag

## flag.Lookup

获取flag集合中名称为name值的flag指针，如果对应的flag不存在，返回nil

flag中的示例：

~~~go
package main

import (
	"flag"
	"fmt"
)

func main(){
	var a int
	flag.IntVar(&a,"name_a",12346,"this is a test")
	fmt.Println(a)
	a1 := flag.Lookup("name_a")
	fmt.Printf("%T\n",a1)
	fmt.Println(a1.Name)
}
~~~

输出：

~~~
12346
*flag.Flag
name_a
~~~

使用Flagset创建一个Flag的集合，则该集合也可以使用lookup函数了，注意要使用NewFlagsSet创建的myflagset来调用Lookup函数，不能直接使用flag.Lookup，示例如下：

~~~go
package main

import (
	"flag"
	"fmt"
)

var myFlagSet = flag.NewFlagSet("flagsettest", flag.ExitOnError)
var flag1 string
func init(){
	myFlagSet.StringVar(&flag1,"abc", "default value", "help mesage")
}


func main() {
	fmt.Println(myFlagSet.Lookup("abc").Value)
	fmt.Println(flag1)
}
~~~

