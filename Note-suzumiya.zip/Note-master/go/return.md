# 函数return值的三种情况

* **退出执行，不指定返回值**

1.  函数没有返回值

   ~~~go
   package main
   import (
       "fmt"
   )
   
   func GetMoney(){
   fmt.Println("money")
     return
   }
   
   func main(){
     GetMoney()
   }
   ~~~

2. 函数返回值有变量名

   ```go
   package main
   import (
       "fmt"
   )
   
   func GetMoney() (_amount int){
    _amount = 88
    fmt.Println("money: ",_amount)
     return
   }
   
   func main(){
     var amount  = GetMoney()
     fmt.Println("money: ",amount)
   }
   ```

* **退出执行，指定返回值**

  ~~~go
  package main
  import (
      "fmt"
  )
  
  func GetMoney() (_amount int){
   fmt.Println("money: ",_amount)
    return 88
  }
  
  func main(){
    var amount  = GetMoney()
    fmt.Println("money: ",amount)
  }
  
  运行结果：
  money:  0
  money:  88
  ~~~

* **退出执行，指定返回值和指定默认值**

  ~~~go
  package main
  import (
      "fmt"
  )
  
  func GetMoney() (_amount int){
  _amount  = 99     //如果return后面没有指定返回值，就用赋给“返回值变量”的值
   fmt.Println("money: ",_amount)
    return 88       //如果return后面跟有返回值，就使用return后面的返回值
  }
  
  func main(){
    var amount  = GetMoney()  
    fmt.Println("money: ",amount)
  }
  
  运行结果：
  money:  99
  money:  88
  ~~~

  

# 关于return参数

func GetNum(a int)(int,int) 这个函数的返回值为两个int类型的变量，这种情况下，可以在函数中声明要返回的变量，也就是可以 var b,c int，并在return 中填入要返回的变量，示例代码如下

~~~go
package main

import "fmt"

func GetNum(a int)(int,int){
	fmt.Println("a:",a)
	var z1,z2,b,c int
	z1 = 2
	z2 = 3
	c = z1
	b = z2
	fmt.Println("c1,b1",c,b)
	return c,b
}

func main(){

	var z1 int = 1
	var r1,r2 int
	r1,r2 = GetNum(z1)
	fmt.Println("r1,r2:",r1,r2)
}

~~~



func GetNum(a int)(c int,b int)这个函数的返回值指明返回变量为b,c，并指明返回变量的类型为int，这种情况下，不能再GetNum函数中再次声明b,c变量，也就是var b,c,会报错，return中不用写要返回的变量，示例代码如下：

~~~go
package main

import "fmt"

func GetNum(a int)(c int,b int){
	fmt.Println("a:",a)
	var z1,z2 int
	z1 = 2
	z2 = 3
	c = z1
	b = z2
	fmt.Println("c1,b1",c,b)
	return
}

func main(){

	var z1 int = 1
	var r1,r2 int
	r1,r2 = GetNum(z1)
	fmt.Println("r1,r2:",r1,r2)
}

~~~

