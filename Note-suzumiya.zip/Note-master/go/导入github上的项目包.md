# 通过go get下载包失败

国内使用`go get`命令安装包时会经常会出现timeout的问题。可以通过以下方法。

## 使用goproxy

Go的1.11版本以后 可以设置GOPROXY这个变量，来设置代理。 如果你自己有代理服务器就可以把这个环境变量设置成自己的代理。

**如果您使用的 Go 版本是 1.13 及以上 （推荐）**

~~~shell
go env -w GO111MODULE=on
go env -w GOPROXY=https://goproxy.io,direct

# 设置不走 proxy 的私有仓库，多个用逗号相隔（可选）
go env -w GOPRIVATE=*.corp.example.com

# 设置不走 proxy 的私有组织（可选）
go env -w GOPRIVATE=example.com/org_name
~~~

设置完上面几个环境变量后，您的 `go` 命令将从公共代理镜像中快速拉取您所需的依赖代码了

**如果您使用的 Go 版本是 1.12 及以下**

在Mac/linux下执行：

~~~shell
# 启用 Go Modules 功能
export GO111MODULE=on
# 配置 GOPROXY 环境变量
export GOPROXY=https://goproxy.io
~~~

或者，根据[文档](https://goproxy.io/zh/docs/getting-started.html)可以把上面的命令写到`.profile`或`.bash_profile`文件中长期生效。

Windows平台执行：

~~~shell
# 启用 Go Modules 功能
set GO111MODULE=on
# 配置 GOPROXY 环境变量
set GOPROXY=https://goproxy.io
~~~

**windows环境下使用goland配置**

在goland左下角点开Terminal，打开控制台，然后进行配置，配置如下图。

<img src="微信图片_20200629192217.png" style="zoom:50%;" />

![](微信图片_20200629192930.png)

使用go env查看go语言环境配置

![](微信图片_20200629194052.png)

如上图配置成功，可以使用go get来获取第三方包。



**注意：如果将`go env -w GO111MODULE=on`设为on, 则会使用1.13的mod包特性,下载的包不会在`src`目录下**

**参考：**https://goproxy.io/zh/

[https://goproxy.io/zh/docs/getting-started.html#%E5%BC%80%E5%90%AF-go-module-%E5%8A%9F%E8%83%BD](https://goproxy.io/zh/docs/getting-started.html#开启-go-module-功能)

https://blog.csdn.net/tmt123421/article/details/88665248

https://blog.csdn.net/qq_43442524/article/details/104900180

# linux下 修改hosts文件（未验证）

centos7中，go get失败，修改hosts文件。

可以通过ip查询来获取ip地址。ip查询网站：https://www.ipaddress.com/ip-lookup

~~~
vim /etc/hosts
140.82.113.4  github.com
199.232.69.194 github.global.ssl.fastly.net
~~~

重启后使用 go get

**参考：**https://blog.csdn.net/fly_520/article/details/81448930



# 关于go get 以后下载的包不在src下而在pkg的源头并且不可以import(Goland Modules模块的使用)

`go get` 以后我发现下载的包不在`src`目录下生成,而全部到了`$GOPATH$/pkg`目录下,如下图所示

![](微信图片_20200629194818.png)

而且下载完了, `import`也不成功

![](微信图片_20200629195311.png)

**原因：因为`go env -w GO111MODULE=on`选择了打开**

>官方在 v1.11 中加入了 Go Module 作为官方包管理形式，就这样 dep 无奈的结束了使命。
>最初的 Go Module 提案的名称叫做 vgo，下面为了介绍简称为 gomod。不过在 v1.11 和 v1.12 的 Go 版本中 gomod 是不能直接使用的。
>可以通过 go env 命令返回值的 GOMOD 字段是否为空来判断是否已经开启了 gomod，如果没有开启，可以通过设置环境变量 
>export 	GO111MODULE=on 开启

## go mod的使用

首先要把go升级到1.11及以上~

在你需要导入第三方包的地方,打开终端输入`go mod init name`,name为自己想要输入的名字

![](微信图片_20200629195752.png)

然后该文件夹出现go.mod文件

![1593431923349](1593431923349.png)

然后使用go get 你想要导入的包地址

![1593432170051](1593432170051.png)

这样go.mod里会记录你导入的包名称以及版本号

![1593432345707](1593432345707.png)

这样包就可以正常使用了



### goland中进行配置

在goland中如果要使用mod,除了上述步骤生成go.mod文件后，还需要对goland进行配置，设置如下。在Go Mouldes 中打开代理配置。

`https://goproxy.io` 设置代理

![1593432758697](1593432758697.png)

完成配置后，重启goland，包可以正常导入了。

![1593432878564](1593432878564.png)



## go get 出现unrecognized import path

使用go get时遇到如下错误

~~~
#go get  github.com/spf13/cobra/cobra  

unrecognized import path "golang.org/x/sys/unix": https fetch: Get "https://golang.org/x/sys/unix?go-get=1": dial tcp 216.239.37.1:443: i/o timeout
unrecognized import path "golang.org/x/text/transform": https fetch: Get "https://golang.org/x/text/transform?go-get=1": dial tcp 216.239.37.1:443: i/o timeout
unrecognized import path "golang.org/x/text/unicode/norm": https fetch: Get "https://golang.org/x/text/unicode/norm?go-get=1": dial tcp 216.239.37.1:443: i/o timeout
~~~

解决方法如下，其实 golang 在 github 上建立了一个镜像库，如 https://github.com/golang/net 即是 https://golang.org/x/net 的镜像库

~~~
进入gopath的src目录：
cd ~/go/src

创建目录：
mkdir -p  golang.org/x/

进入刚创建的目录：
cd golang.org/x

克隆git库：
git clone https://github.com/golang/sys.git
git clone https://github.com/golang/text.git
~~~

其它 golang.org/x 下的包获取皆可使用该方法

**参考：**https://blog.csdn.net/qq_43442524/article/details/104906475

https://zhuanlan.zhihu.com/p/30964604