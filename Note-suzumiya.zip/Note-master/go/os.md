os.Stderr对应的是UNIX里的标准错误警告信息的输出设备，同时被作为默认的日志输出目的地。初次之外，还有标准输出设备os.Stdout以及标准输入设备os.Stdin。

~~~go
var (
	Stdin  = NewFile(uintptr(syscall.Stdin), "/dev/stdin")
	Stdout = NewFile(uintptr(syscall.Stdout), "/dev/stdout")
	Stderr = NewFile(uintptr(syscall.Stderr), "/dev/stderr")
)
~~~

以上就是定义的UNIX的标准的三种设备，分别用于输入、输出和警告错误信息。

