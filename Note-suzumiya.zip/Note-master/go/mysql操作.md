# 概念

## 预处理

预处理是 MySQL 为了防止客户端频繁请求的一种技术，是对相同处理语句进行预先加载在 MySQL 中，将操作变量数据用占位符来代替，减少对 MySQL 的频繁请求，使得服务器高效运行。

在这里客户端并不是前台后台之间的 C/S 架构，而是后台程序对数据库服务器进行操作的 C/S 架构，这样就可以简要地理解了后台程序作为 Client 向 MySQL Server 请求并处理结果了。

### 普通 SQL 执行处理过程： 

1. 在客户端准备 SQL 语句；
2. 发送 SQL 语句到 MySQL 服务器；
3. 在 MySQL 服务器执行该 SQL 语句；
4. 服务器将执行结果返回给客户端。

### **预处理执行处理过程：**

将 SQL 拆分为结构部分与数据部分；
在执行 SQL 语句的时候，首先将前面相同的命令和结构部分发送给 MySQL 服务器，让 MySQL 服务器事先进行一次预处理（此时并没有真正的执行 SQL 语句）；
为了保证 SQL 语句的结构完整性，在第一次发送 SQL 语句的时候将其中可变的数据部分都用一个数据占位符来表示；
然后把数据部分发送给 MySQL 服务端，MySQL 服务端对 SQL 语句进行占位符替换；
MySQL 服务端执行完整的 SQL 语句并将结果返回给客户端。

### 预处理优点

- 预处理语句大大**减少了分析时间**，只做了一次查询（虽然语句多次执行）；
- 绑定参数**减少了服务器带宽**，只需发送查询的参数，而不是整个语句；
- 预处理语句针对 **SQL 注入**是非常有用的，因为参数值发送后使用不同的协议，保证了数据的合法性。

### Go 语言实现

在 Go 语言中，使用 `db.Prepare()` 方法实现预处理：

~~~go
func (db *DB) Prepare(query string) (*Stmt, error)
~~~

Prepare 执行预处理 SQL 语句，并返回 Stmt 结构体指针，进行数据绑定操作。

查询操作使用 `db.Prepare()` 方法声明预处理 SQL，使用 `stmt.Query()` 将数据替换占位符进行查询，更新、插入、删除操作使用 `stmt.Exec()` 来操作。

#  go语言的mysql操作

安装必要依赖

~~~
go get  github.com/go-sql-driver/mysql
~~~

# 连接数据库

~~~go
package main

import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
)

func main(){
	db,_:=sql.Open("mysql","kubenet:123456@(192.168.1.242:3306)/kubeNET") // 设置连接数据库的参数
	defer db.Close()    //关闭数据库
	err:=db.Ping()      //连接数据库
	if err!=nil{
		fmt.Println("数据库连接失败")
		return
	}
}
~~~

其中，sql.Open( )含义为

~~~
db, err := sql.Open("mysql", "user:password@tcp(IP:PORT)/databasename")
~~~

格式为

~~~
[username[:password]@][protocol[(address)]]/dbname[?param1=value1&...&paramN=valueN]
~~~

具体参数可以参考：https://github.com/Go-SQL-Driver/MySQL

# 查询操作

## 单行查询

~~~go
package main

import (
"database/sql"
"fmt"
_ "github.com/go-sql-driver/mysql"
)

func Query(db *sql.DB){

	rows :=db.QueryRow("select podip from pod whee podname=\"busy\"")

	var	podip	string
	err := rows.Scan(&podip)
	fmt.Println("podip is ",podip)
	if err!=nil{
		fmt.Println("rows.Scan error",err)
		return
	}

}

func main(){
	db,_:=sql.Open("mysql","kubenet:123456@(192.168.1.242:3306)/kubeNET") // 设置连接数据库的参数
	defer db.Close()    //关闭数据库
	err:=db.Ping()      //连接数据库
	if err!=nil{
		fmt.Println("数据库连接失败")
		return
	}
	Query(db)

}
~~~



## 多行查询

~~~go
package main


import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
)

func Query(db *sql.DB){

	rows,err:=db.Query("select * from pod")
	if err!=nil{
		fmt.Println("db.Query error:",err)
		return
	}
	for rows.Next(){
		var podname string
		var	podip	string
		var netcidr string
		var netname string
		err = rows.Scan(&podname,&podip,&netcidr,&netname)
		if err!=nil{
			fmt.Println("rows.Scan error",err)
			return
		}
		if netname==""{
			fmt.Println("netname is null")
		}
		fmt.Printf("podname=%s,podip=%s,netcidr=%s,netname=%s\n",podname,podip,netcidr,netname)
	}
}

func main(){
	db,_:=sql.Open("mysql","kubenet:123456@(192.168.1.242:3306)/kubeNET") // 设置连接数据库的参数
	defer db.Close()    //关闭数据库
	err:=db.Ping()      //连接数据库
	if err!=nil{
		fmt.Println("数据库连接失败")
		return
	}
	Query(db)
}
~~~

需要注意的是空值的问题，某个字段有为空的情况，需要声明数据类型为sql.NullString,取得数据后可以赋值给结构体或者变量，具体以实际需要为主.

# 插入操作

~~~go
package main


import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
)
type Pod struct {
	PodName string
	PodIp	string
	NetCidr	string
	NetName	string
}

func Insert(db *sql.DB,p Pod){
	sql := "insert into pod (podname,podip,netcidr,netname) value (?, ?, ?, ?)"
	stmt, err := db.Prepare(sql)
	//defer stmt.Close()
	if err!=nil{
		fmt.Println("db.prepare失败")
		return
	}

	res, err := stmt.Exec(p.PodName,p.PodIp,p.NetCidr,p.NetName)

	if err!=nil{
		fmt.Println("stmt.Exec error")
		return
	}

	fmt.Printf("成功了,%v", res)


}

func main(){
	db,_:=sql.Open("mysql","kubenet:123456@(192.168.1.242:3306)/kubeNET") // 设置连接数据库的参数
	defer db.Close()    //关闭数据库
	err:=db.Ping()      //连接数据库
	if err!=nil{
		fmt.Println("数据库连接失败")
		return
	}
	pod1 := Pod{
		PodName: "busytest",
		PodIp:   "1.1.1.1",
		NetCidr: "1.1.1.1/24",
		NetName: "",
	}
	Insert(db,pod1)

}
~~~

# 更新操作

~~~go
package main


import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
)
type Pod struct {
	PodName string
	PodIp	string
	NetCidr	string
	NetName	string
}

func Update(db *sql.DB,p Pod){
	sql := "update pod set podip=?  where podname=?"

	stmt, err := db.Prepare(sql)
	//defer stmt.Close()
	if err!=nil{
		fmt.Println("db.prepare失败")
		return
	}

	res, err := stmt.Exec(p.PodIp,p.PodName)

	if err!=nil{
		fmt.Println("stmt.Exec error")
		return
	}

	fmt.Printf("成功了,%v", res)


}

func main(){
	db,_:=sql.Open("mysql","kubenet:123456@(192.168.1.242:3306)/kubeNET") // 设置连接数据库的参数
	defer db.Close()    //关闭数据库
	err:=db.Ping()      //连接数据库
	if err!=nil{
		fmt.Println("数据库连接失败")
		return
	}
	pod1 := Pod{
		PodName: "busy3",
		PodIp:   "1.1.1.15",
		NetCidr: "1.1.1.1/24",
		NetName: "",
	}
	Update(db,pod1)

}
~~~

# 删除操作

~~~go
package main


import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
)
type Pod struct {
	PodName string
	PodIp	string
	NetCidr	string
	NetName	string
}

func Delate(db *sql.DB,p Pod){
	sql := "delete from pod where podname=? "

	stmt, err := db.Prepare(sql)
	defer stmt.Close()
	if err!=nil{
		fmt.Println("db.prepare失败")
		return
	}

	res, err := stmt.Exec(p.PodName)

	if err!=nil{
		fmt.Println("stmt.Exec error")
		return
	}

	fmt.Printf("成功了,%v", res)


}

func main(){
	db,_:=sql.Open("mysql","kubenet:123456@(192.168.1.242:3306)/kubeNET") // 设置连接数据库的参数
	defer db.Close()    //关闭数据库
	err:=db.Ping()      //连接数据库
	if err!=nil{
		fmt.Println("数据库连接失败")
		return
	}
	pod1 := Pod{
		PodName: "busy3",
		PodIp:   "1.1.1.15",
		NetCidr: "1.1.1.1/24",
		NetName: "",
	}
	Delate(db,pod1)

}
~~~



**参考**：https://blog.csdn.net/walkcode/article/details/103370141

https://blog.csdn.net/M728838939/article/details/107088947/

https://www.jianshu.com/p/7e745fefb8af

[https://shuzang.github.io/development-of-online-forum-based-on-golang-2-interact-with-mysql/#31-%E6%95%B0%E6%8D%AE%E5%BA%93%E9%A9%B1%E5%8A%A8](https://shuzang.github.io/development-of-online-forum-based-on-golang-2-interact-with-mysql/#31-数据库驱动)

https://blog.csdn.net/naiwenw/article/details/79281220