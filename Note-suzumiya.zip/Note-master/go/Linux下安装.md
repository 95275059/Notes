# Linux下的安装

1. 打开官网下载地址选择对应的系统版本，这里选择以下版本。

   ![](.\微信图片_20200330210959.png)

2. 在 ./下创建 go 文件夹。

   ~~~
   mkdir ~/go 
   ~~~

3. 执行tar解压到/usr/loacl目录下（官方推荐），得到go文件夹等。

   ~~~
   tar -C /usr/local -xzf go1.14.1.linux-amd64.tar.gz
   ~~~

4. 添加/usr/loacl/go/bin目录到PATH变量中。添加到/etc/profile(对全系统安装)或$HOME/.profile都可以。

   ~~~
   vim /etc/profile
   # 在最后一行添加
   export GOROOT=/usr/local/go
   export PATH=$PATH:$GOROOT/bin
   # 保存退出后source一下
   source /etc/profile
   ~~~

   

5. 执行`go version`，如果现实版本号，则Go环境安装成功。

   ![](.\微信图片_20200330212959.png)

   

# 运行第一个程序

1. 先创建你的工作空间([Workspaces](https://www.jianshu.com/p/[workspace](https://golang.org/doc/code.html#Workspaces)))，官方建议目录`$HOME/go`。

2. 将你的工作空间路径声明到环境变量中。和上一部分的第4步相似。

   ~~~
   # 编辑 ~/.bash_profile 文件
   vim ~/.bash_profile
   # 在最后一行添加下面这句。$HOME/go 为你工作空间的路径，你也可以换成你喜欢的路径
   export GOPATH=$HOME/go
   # 保存退出后source一下
   source ~/.bash_profile
   ~~~

3. 在你的工作空间创建你的第一个工程目录。

   ~~~
   # 创建并进入你的第一个工程目录
   mkdir -p $GOPATH/src/hello && cd $GOPATH/src/hello
   ~~~

4. 在你的工程目录下创建名为hello.go的文件。

   ```shell
   vim hello.go
   ```

   输入如下内容

   ~~~
   package main
   
   import "fmt"
   
   func main() {
       fmt.Printf("hello, world\n")
   }
   ~~~

5. 到我们的工程目录(`$GOPATH/src/hello`)下构建工程。

   ~~~
   # 如果你当前的目录不在 $GOPATH/src/hello， 需要先执行 "cd $GOPATH/src/hello" 进入该目录
   # 执行构建工程的命令
   go build
   ~~~

   

6. 命令执行完之后你可以看到目录下会多出一个 hello 的文件，这就是编译之后的文件。怎么执行程序呢？只需要在当前目录下执行`./xxx`就可以啦！

   ~~~
   ./hello
   ~~~

   ![](.\微信图片_20200330213548.png)

7. 也可以运行

   ~~~
   go run hello.go
   ~~~

   ![](.\微信图片_20200330213843.png)

# 关于Go的一些介绍

## 环境变量

$GOROOT:
表示Go的安装目录。也就是上面我们解压出来的文件夹里面的go文件夹。
$GOPATH:
表示我们的工作空间。用来存放我们的工程目录的地方。

## GOPATH目录：

 一般来说GOPATH下面会有三个文件夹：bin、pkg、src，没有的话自己创建。每个文件夹都有其的作用。

bin：编译后可的执行文件的存放路径
pkg：编译包时，生成的.a文件的存放路径
src：源码路径，一般我们的工程就创建在src下面。
注意：如果要用Go Mod(Go1.11及以上支持)进行包管理，则需要在 GOPATH 以外的目录创建工程。关于Go Mod的使用，可以自行Google一下，这里就不赘述了。

