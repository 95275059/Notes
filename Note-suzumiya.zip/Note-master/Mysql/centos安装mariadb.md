# CentOS 7 安装MariaDB

MariaDB 数据库管理系统是 MySQL 的一个分支，主要由开源社区在维护，采用 GPL 授权许可。开发这个分支的原因之一是：甲骨文公司收购了 MySQL 后，有将 MySQL 闭源的潜在风险，因此社区采用分支的方式来避开这个风险。MariaDB完全兼容mysql，使用方法也是一样的。

## 安装环境

Centos 7.5

## 安装步骤

### 1.安装MariaDB

​	通过yum安装就行了。简单快捷，安装mariadb-server，默认依赖安装mariadb，一个是服务端、一个是客户端。

~~~shell
yum install mariadb-server
~~~

### 2.配置MariaDB

 1. 安装完成后首先要把MariaDB服务开启，并设置为开机启动

    ~~~shell
    systemctl start mariadb	# 开启服务 
    systemctl enable mariadb	# 设置为开机自启动服务
    ~~~

 2. 首次安装需要进行数据库的配置，命令都和mysql的一样

    ~~~
    mysql_secure_installation
    ~~~

 3. 配置是出现的各个选项

    ~~~shell
    Enter current password for root (enter for none):  # 输入数据库超级管理员root的密码(注意不是系统root的密码)，第一次进入还没有设置密码则直接回车
    
    Set root password? [Y/n]  # 设置密码，y
    
    New password:  # 新密码
    Re-enter new password:  # 再次输入密码
    
    Remove anonymous users? [Y/n]  # 移除匿名用户， y
    
    Disallow root login remotely? [Y/n]  # 拒绝root远程登录，n，不管y/n，都会拒绝root远程登录
    
    Remove test database and access to it? [Y/n]  # 删除test数据库，y：删除。n：不删除，数据库中会有一个test数据库，一般不需要
    
    Reload privilege tables now? [Y/n]  # 重新加载权限表，y。或者重启服务也行
    ~~~

    

 4. 测试是否能够登录成功，出现  MariaDB [(none)]> 就表示已经能够正常登录使用MariaDB数据库了

    ~~~
    [root@k8smaster ~]# mysql -u root -p 
    Enter password: 
    Welcome to the MariaDB monitor.  Commands end with ; or \g.
    Your MariaDB connection id is 10
    Server version: 10.1.19-MariaDB MariaDB Server
    
    Copyright (c) 2000, 2016, Oracle, MariaDB Corporation Ab and others.
    
    Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.
    
    MariaDB [(none)]> 
    ~~~

### 3.设置MariaDB字符集为utf-8

1. /etc/my.cnf 文件

   在  [mysqld]  标签下添加（如果没有该标签，则添加该标签）

   ~~~
   init_connect='SET collation_connection = utf8_unicode_ci'
   init_connect='SET NAMES utf8'
   character-set-server=utf8
   collation-server=utf8_unicode_ci
   skip-character-set-client-handshake
   ~~~

2. /etc/my.cnf.d/client.cnf 文件

   在  [client]  标签下添加

   ~~~
   default-character-set=utf8
   ~~~

3. /etc/my.cnf.d/mysql-clients.cnf  文件

   在  [mysql]  标签下添加

   ~~~
   default-character-set=utf8
   ~~~

4. 重启服务

   ~~~
   systemctl restart mariadb
   ~~~

5. 进入mariadb查看字符集

   修改配置文件前的字符集如下

   ~~~mysql
   MariaDB [(none)]> show variables like "%character%";show variables like "%collation%";
   +--------------------------+----------------------------+
   | Variable_name            | Value                      |
   +--------------------------+----------------------------+
   | character_set_client     | utf8                       |
   | character_set_connection | utf8                       |
   | character_set_database   | latin1                     |
   | character_set_filesystem | binary                     |
   | character_set_results    | utf8                       |
   | character_set_server     | latin1                     |
   | character_set_system     | utf8                       |
   | character_sets_dir       | /usr/share/mysql/charsets/ |
   +--------------------------+----------------------------+
   8 rows in set (0.01 sec)
   
   +----------------------+-------------------+
   | Variable_name        | Value             |
   +----------------------+-------------------+
   | collation_connection | utf8_general_ci   |
   | collation_database   | latin1_swedish_ci |
   | collation_server     | latin1_swedish_ci |
   +----------------------+-------------------+
   3 rows in set (0.00 sec)
   
   MariaDB [(none)]>
   ~~~

   修改配置文件后的字符集如下

   ~~~mysql
   MariaDB [(none)]> show variables like "%character%";show variables like "%collation%";
   +--------------------------+----------------------------+
   | Variable_name            | Value                      |
   +--------------------------+----------------------------+
   | character_set_client     | utf8                       |
   | character_set_connection | utf8                       |
   | character_set_database   | utf8                       |
   | character_set_filesystem | binary                     |
   | character_set_results    | utf8                       |
   | character_set_server     | utf8                       |
   | character_set_system     | utf8                       |
   | character_sets_dir       | /usr/share/mysql/charsets/ |
   +--------------------------+----------------------------+
   8 rows in set (0.01 sec)
   
   +----------------------+-----------------+
   | Variable_name        | Value           |
   +----------------------+-----------------+
   | collation_connection | utf8_unicode_ci |
   | collation_database   | utf8_unicode_ci |
   | collation_server     | utf8_unicode_ci |
   +----------------------+-----------------+
   3 rows in set (0.00 sec)
   
   MariaDB [(none)]> 
   ~~~

### 4.远程链接MariaDB数据库

​	mariadb默认是拒绝 root 远程登录的。这里用的是 navicat 软件连接数据库

1. 关闭防火墙

   1). 关闭防火墙 systemctl stop firewalld 

   ~~~
   systemctl stop firewalld
   ~~~

   2). 在不关闭防火墙的情况下，允许某端口的外来链接。步骤如下，开启3306端口，重启防火墙(未尝试)

   ~~~
   firewall-cmd --query-port=3306/tcp  # 查看3306端口是否开启
   no
   firewall-cmd --zone=public --add-port=3306/tcp --permanent  # 开启3306端口
   success
   firewall-cmd --reload  # 重启防火墙
   success
   firewall-cmd --query-port=3306/tcp  # 查看3306端口是否开启
   yes
   ~~~

2. 先查看mysql数据库中的user表

   ~~~
   [root@k8smaster ~]# mysql -u root -p  # 先通过本地链接进入数据库
   
   MariaDB [(none)]> use mysql;
   
   MariaDB [mysql]> select host, user from user;
   +-----------+------+
   | host      | user |
   +-----------+------+
   | 127.0.0.1 | root |
   | ::1       | root |
   | k8smaster | root |
   +-----------+------+
   3 rows in set (0.00 sec)
   ~~~

3. 将与主机名相等的字段改为 "%" ，我的主机名为k8smaster，

   ~~~
   MariaDB [mysql]> update user set host='%' where host='k8smaster';
   Query OK, 1 row affected (0.00 sec)
   Rows matched: 1  Changed: 1  Warnings: 0
   
   MariaDB [mysql]> select host, user from user;
   +-----------+------+
   | host      | user |
   +-----------+------+
   | %         | root |
   | 127.0.0.1 | root |
   | localhost | root |
   +-----------+------+
   3 rows in set (0.00 sec)
   ~~~

4. 刷新权限表，或重启mariadb服务，一下二选一即可

   ~~~
   MariaDB [mysql]> flush privileges;
   Query OK, 0 rows affected (0.00 sec)
   ~~~

   ~~~
   systemctl restart mariadb
   ~~~

   刷新权限表是在数据库中，重启服务是在外部命令行中

5. 使用navicat重新远程链接mariadb

   ![1594045265582](1594045265582.png)

**参考：**https://www.cnblogs.com/yhongji/p/9783065.html

