Ctrl+d      删除光标所在位置上的字符，相当于vi里x或者dl。

Ctrl+k      删除光标后面所有字符，相当于vi里d Shift+$。

Ctrl+u      删除光标前面所有字符，相当于vi里d Shift+^。

Ctrl+?      撤消前一次输入。

Ctrl+r       输入单词搜索历史命令。

ctrl + i       类似TAB健补全功能

