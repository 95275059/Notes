# shell 输出输入重定向

| 命令            | **说明**                          |
| --------------- | --------------------------------- |
| command > file  | 将输出重定向到 file。             |
| command < file  | 将输入重定向到 file。             |
| command >> file | 将输出以追加的方式重定向到 file。 |

## Here Document

Here Document 是 Shell 中的一种特殊的重定向方式，用来将输入重定向到一个交互式 Shell 脚本或程序。

它的基本的形式如下：

~~~
command << delimiter
    document
delimiter
~~~

它的作用是将两个 delimiter 之间的内容(document) 作为输入传递给 command。

> 注意：
>
> - 结尾的delimiter 一定要顶格写，前面不能有任何字符，后面也不能有任何字符，包括空格和 tab 缩进。
> - 开始的delimiter前后的空格会被忽略掉。

以下为例子：

~~~
cat << EOF
> 欢迎来到
> 菜鸟教程
> www.runoob.com
> EOF

输出为
欢迎来到
菜鸟教程
www.runoob.com

~~~

