# Git远程分支管理

~~~
git pull # 抓取远程仓库所有分支更新并合并到本地
 
git pull --no-ff # 抓取远程仓库所有分支更新并合并到本地，不要快进合并
 
git fetch origin # 抓取远程仓库更新
 
git merge origin/master # 将远程主分支合并到本地当前分支
~~~

# git push # push所有分支

~~~
git push origin master # 将本地主分支推到远程主分支
 
git push -u origin master # 将本地主分支推到远程(如无远程主分支则创建，用于初始化远程仓库)
 
git push origin <local_branch> # 创建远程分支， origin是远程仓库名
 
git push origin <local_branch>:<remote_branch> # 创建远程分支
 
git push origin :<remote_branch> #先删除本地分支(git br -d <branch>)，然后再push删除远程分支
~~~

# Git远程仓库管理

~~~
git remote -v # 查看远程服务器地址和仓库名称
 
git remote show origin # 查看远程服务器仓库状态
 
git remote add origin git@ github:robbin/robbin_site.git # 添加远程仓库地址

git remote set-url origin git@ github.com:robbin/robbin_site.git # 设置远程仓库地址(用于修改远程仓库地址) git
~~~

