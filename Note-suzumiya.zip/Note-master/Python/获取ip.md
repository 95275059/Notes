# 获取本机ip

~~~python
# !/usr/bin/python3
import socket, struct, fcntl

def get_ip(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s', bytes(ifname[:15], 'utf-8')))[20:24])

print(get_ip('eth0'))
~~~



# 配置虚拟ip

可以使用shell或者Python来写配置虚拟ip。

使用shell来配置虚拟ip

~~~shell
#!/bin/bash
w=0
for((j=18;j<255;j++))
do
        while [ $w != 25000 ]
        do
        ifconfig eth0:$w 71.0.0.$j netmask 255.255.0.0 up
        w=$(($w + 1))
        break
        done
done
for ((i=1;i<255;i++))
do
    for((j=1;j<255;j++))
      do
        while [ $w != 25000 ]
        do
        ifconfig eth0:$w 71.0.$i.$j netmask 255.255.0.0 up
        w=$(($w + 1))
        break
        done
      done
done
~~~

使用python来写虚拟ip。os.system函数可以将字符串转化成命令在服务器上运行；其原理是每一条system函数执行时，其会创建一个子进程在系统上执行命令行，子进程的执行结果无法影响主进程；

~~~ python
w =0
a =1
for i in range(a,256):
    if w<15000:
        os.system('ifconfig eth0:%d %d.%d.0.%d netmask 255.255.0.0 up'%(w,i11,i12,i))
        w = w+1
for  i in range(1,256):
    for j in range(1,256):
        if w<15000:
            os.system('ifconfig eth0:%d %d.%d.%d.%d netmask 255.255.0.0 up' % (w,i11,i12,i,j))
            w = w+1
        else:
            exit(0)
~~~

获取本地ip后，部署虚拟ip。

~~~ python
# coding: utf-8
import os
import socket, struct, fcntl

def get_ip(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s', bytes(ifname[:15], 'utf-8')))[20:24])

ip = get_ip('eth0')
ipchar = ip.split('.')

i01 = ipchar[0]
i11 = int(i01)
i02 = ipchar[1]
i12 = int(i02)
i03 = ipchar[2]
i13 = int(i03)
i04 = ipchar[3]
i14 = int(i04)

w =0
a = i14+1
for i in range(a,256):
    if w<15000:
        os.system('ifconfig eth0:%d %d.%d.0.%d netmask 255.255.0.0 up'%(w,i11,i12,i))
        w = w+1
for  i in range(1,256):
    for j in range(1,256):
        if w<15000:
            os.system('ifconfig eth0:%d %d.%d.%d.%d netmask 255.255.0.0 up' % (w,i11,i12,i,j))
            w = w+1
        else:
            exit(0)
~~~

