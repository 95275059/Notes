# xml.dom.minidom

## xml.dom.minidom函数

部分函数

```
doc=xml.dom.minidom.parse(filename)         #加载和读取xml文件
root=doc.documentElement                    #获取xml文档对象
node.getAttribute(AttributeName)            #获取xml节点属性值
node.getElementsByTagName(TagName)          #获取xml节点对象集合
node.childNodes                             #获取子节点列表
node.childNodes[index].nodeValue        	#获取xml节点值
node.firstChild                             #访问第一个节点
n.childNodes[0].data                        #获得文本值
node.childNodes[index].nodeValue            #获取XML节点值

doc.toxml('utf-8')                          #返回Node节点的xml表示的文本
```



## xml.dom.minidom函数使用

使用以下xml文档示例

~~~xml
<?xml version="1.0" encoding="UTF-8"?>
<data>
    <country name="Liechtenstein">
        <rank updated="yes">3</rank>
        <year>2008</year>
        <gdppc>141100</gdppc>
        <neighbor direction="E" name="Austria" />
        <neighbor direction="W" name="Switzerland" />
    </country>
    <country name="Singapore">
        <rank updated="yes">6</rank>
        <year>2011</year>
        <gdppc>148500</gdppc>
        <neighbor direction="N" name="Malaysia" />
    </country>
    <country name="Panama">
        <rank updated="yes">70</rank>
        <year>2011</year>
        <gdppc>13600</gdppc>
        <neighbor direction="W" name="Costa Rica" />
        <neighbor direction="E" name="Colombia" />
    </country>
</data>
~~~

从文件载入xml

~~~
import xml.dom.minidom

dom = xml.dom.minidom.parse("01.xml")  
root = dom.documentElement
~~~

或直接直接从字符串载入

~~~
import xml.dom.minidom

dom = xml.dom.minidom.parseString(xml1)
root = dom.documentElement
~~~

获取元素

~~~
countries = root.getElementsByTagName('country')
print type(countries)

c = countries[0]
print c.nodeName
print c.nodeValue

-----------------------------------------
<class 'xml.dom.minicompat.NodeList'>
country
None
~~~

可以直接选取任一节点进行访问如，选择years

~~~
years = root.getElementsByTagName('year')

for year in years:
    print year.childNodes[0].data   # 或使用 year.childNodes[0].nodeValue
    
-----------------------------------------
2008
2011
2011
~~~

获取某个year的值

~~~
years = root.getElementsByTagName('year')

y1 = years[0]

print y1.childNodes[0].nodeValue

-----------------------------------------
2008
~~~

获取节点属性值

~~~
countries = root.getElementsByTagName('country')

for country in countries:
    print country.getAttribute('name')
    
-----------------------------------------
Liechtenstein
Singapore
Panama
~~~

将年份修改为2019，并保存修改好的xml

~~~
str1 = 2019
dom = xmldom.parseString(xml1)
root = dom.documentElement
message = root.getElementsByTagName('year')
for node in message:
    node.childNodes[0].data = str1
test = dom.toxml()        # 使用toxml 进行保存

print test
~~~



遍历示例：

~~~python
import xml.dom.minidom as xmldom

xml1 ="""<?xml version="1.0" encoding="UTF-8"?>
<data>
    <country name="Liechtenstein">
        <rank updated="yes">3</rank>
        <year>2008</year>
        <gdppc>141100</gdppc>
        <neighbor direction="E" name="Austria" />
        <neighbor direction="W" name="Switzerland" />
    </country>
    <country name="Singapore">
        <rank updated="yes">6</rank>
        <year>2011</year>
        <gdppc>148500</gdppc>
        <neighbor direction="N" name="Malaysia" />
    </country>
    <country name="Panama">
        <rank updated="yes">70</rank>
        <year>2011</year>
        <gdppc>13600</gdppc>
        <neighbor direction="W" name="Costa Rica" />
        <neighbor direction="E" name="Colombia" />
    </country>
</data>"""

dom = xmldom.parseString(xml1)
root = dom.documentElement

countries = root.getElementsByTagName('country')

for country in countries:
    print '-----------------------'
    print 'Name:',country.getAttribute('name')

    rank = country.getElementsByTagName('rank')[0]
    print 'Rank:',rank.childNodes[0].data
    year = country.getElementsByTagName('year')[0]
    print 'year:', year.childNodes[0].data
    gdppc = country.getElementsByTagName('gdppc')[0]
    print 'gdppc:', gdppc.childNodes[0].data
    neighbor = country.getElementsByTagName('neighbor')[0]
    print 'neighbor name:', neighbor.getAttribute('name')

    if country.getAttribute('name') != 'Singapore':
        neighbor = country.getElementsByTagName('neighbor')[1]
        print 'neighbor name:', neighbor.getAttribute('name')

-------------------------------------------------------------------------------
-----------------------
Name: Liechtenstein
Rank: 3
year: 2008
gdppc: 141100
neighbor name: Austria
neighbor name: Switzerland
-----------------------
Name: Singapore
Rank: 6
year: 2011
gdppc: 148500
neighbor name: Malaysia
-----------------------
Name: Panama
Rank: 70
year: 2011
gdppc: 13600
neighbor name: Costa Rica
neighbor name: Colombia

~~~



## xml.dom.minidom 和xml.etree.ElementTree区别

使用xml.dom.minidom 从字符串读取xml，对xml进行修改，并使用toxml进行保存，保存到变量中，然后对保存好的xml进行操作。

使用xml.etree.ElementTree  从字符串读取xml，修改后好像只能保存输出到文件中，无法保存到变量中（目前没有发现方法），所以修改后不方便操作。



参考：https://www.cnblogs.com/dengyg200891/p/5015999.html

​			[https://docs.python.org/3/library/xml.dom.minidom.html?highlight=xml%20dom%20minidom#module-xml.dom.minidom](https://docs.python.org/3/library/xml.dom.minidom.html?highlight=xml dom minidom#module-xml.dom.minidom)

​			https://www.runoob.com/python/python-xml.html

​			https://www.cnblogs.com/kaituorensheng/p/4493306.html