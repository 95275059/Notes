# xml.etree.ElementTree

## 解析xml

以下xml文档为示例

~~~xml
<data>
    <country name="Liechtenstein">
        <rank updated="yes">3</rank>
        <year>2008</year>
        <gdppc>141100</gdppc>
        <neighbor direction="E" name="Austria" />
        <neighbor direction="W" name="Switzerland" />
    </country>
    <country name="Singapore">
        <rank updated="yes">6</rank>
        <year>2011</year>
        <gdppc>59900</gdppc>
        <neighbor direction="N" name="Malaysia" />
    </country>
    <country name="Panama">
        <rank updated="yes">70</rank>
        <year>2011</year>
        <gdppc>13600</gdppc>
        <neighbor direction="W" name="Costa Rica" />
        <neighbor direction="E" name="Colombia" />
    </country>
</data>
~~~

我们可以通过读取文件来导入这些数据：

~~~
import xml.etree.ElementTree as ET
tree = ET.parse('country_data.xml')
root = tree.getroot()
~~~

或直接从字符串：

```python
root = ET.fromstring(country_data_as_string)
```

fromstring()将字符串中的XML直接解析为an Element，这是解析树的根元素。

~~~
print root.tag

data
~~~

~~~
print print root.attrib

{}
~~~

访问子节点

~~~
for child in root:
    print child.tag,child.attrib
    
country {'name': 'Liechtenstein'}
country {'name': 'Singapore'}
country {'name': 'Panama'}
~~~

子项是嵌套的，我们可以通过索引访问特定的子节点：

~~~
root[0][1].text

2008
~~~

## 寻找元素

Element有一些有用的方法可以帮助递归迭代它下面的所有子树（它的子节点，它们的子节点等）。例如， Element.iter()：

~~~
for neighbor in root.iter('neighbor'):
    print neighbor.attrib
    
{'direction': 'E', 'name': 'Austria'}
{'direction': 'W', 'name': 'Switzerland'}
{'direction': 'N', 'name': 'Malaysia'}
{'direction': 'W', 'name': 'Costa Rica'}
{'direction': 'E', 'name': 'Colombia'}
~~~

Element.findall()仅查找具有标记的元素，这些元素是当前元素的直接子元素。 Element.find()查找具有特定标记的第一个子项，并Element.text访问该元素的文本内容。 Element.get()访问元素的属性：

~~~
for country in root.findall('country'):
    rank = country.find('rank').text
    print rank
    name = country.get('name')
    print name
    
3
Liechtenstein
6
Singapore
70
Panama
~~~

通过使用XPath可以更复杂地指定要查找的元素。

## 修改XML文件

ElementTree提供了一种构建XML文档并将其写入文件的简单方法。该方法用于此目的。ElementTree.write()

一旦创建，Element可以通过直接更改其字段（例如Element.text），添加和修改属性（Element.set()方法）以及添加新子项（例如with Element.append()）来操纵对象。

假设我们想要为每个国家/地区的排名添加一个，并updated 为rank元素添加一个属性：



```
for rank in root.iter('rank'):
    new_rank = int(rank.text) + 1
    rank.text = str(new_rank)
    rank.set('updated', 'yes')

tree.write('output.xml')
```

我们可以使用删除元素Element.remove()。假设我们要删除排名高于50的所有国家/地区：

~~~
for country in root.findall('country'):
     rank = int(country.find('rank').text)
     if rank > 50:
     root.remove(country)

tree.write('output.xml')
~~~





参考 :[https://docs.python.org/3/library/xml.etree.elementtree.html?highlight=xml%20etree%20elementtree](https://docs.python.org/3/library/xml.etree.elementtree.html?highlight=xml etree elementtree)

