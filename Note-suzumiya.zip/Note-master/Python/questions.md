## 字符串比较

* Python2中对两对象的比较。可以用于字符串比较。

  ~~~python
  cmp(x,y)
  ~~~

​	cmp(x,y) 函数用于比较2个对象，如果 x < y 返回 -1, 如果 x == y 返回 0, 如果 x > y 返回 1



* Python3中cmp已经弃用，使用operator可以进行字符串比较。operator有多种功能这里只运用判断是否相等功能。

  ~~~python
  import operator
  operator.eq(a,b) 
  ~~~

  若a和b相等，返回True；若a和b不相等，返回False。 

  

## 异常处理

~~~python
try:
    ...
except:
    ...

~~~

使用

```
except Exception as e
```

可以捕获除与程序退出sys.exit()相关之外的所有异常。

~~~
try:
	do something
except:
	handleexcrpt
~~~

会捕获所有异常，包括键盘中断和程序退出请求（用sys.exit()就无法退出程序了，因为异常被捕获了），因此慎用。





## 退出程序

Python退出程序的方式有两种：os._exit()， sys.exit()

os._exit() 直接退出 Python 解释器，其后的代码都不执行。
sys.exit() 引发一个 SystemExit 异常，没有捕获这个异常，会直接退出；捕获这个异常可以做一些额外的清理工作。

一般来说，os._exit() 用于在线程中退出
		    sys.exit() 用于在主线程中退出。



## 函数参数 *和**

python的函数参数中经常可以看到输入的参数前面有一个或者两个*，例如

~~~
def run1(*args):

def run2(**agrs)
~~~

单星号（*）表示将参数以元组的形式导入，

双星号（**）表示将参数以字典的形式导入。

*和**起到收集参数和分配参数作用

参考：<https://blog.csdn.net/luoyayun361/article/details/83045131>



## python在一个for函数中遍历两个列表

利用python自带的zip函数可同时对两个列表进行遍历

~~~python
list1 = ['a', 'b', 'c', 'd']
list2 = ['apple', 'boy', 'cat', 'dog']
for x, y in zip(list1, list2):
    print(x, 'is', y)
~~~

原理说明：Python3中的zip函数可以把两个或者两个以上的迭代器封装成生成器，这种zip生成器会从每个迭代器中获取该迭代器的下一个值，然后把这些值组装成元组（tuple）。这样，zip函数就实现了平行地遍历多个迭代器。

注意：如果输入的迭代器长度不同，那么，只要有一个迭代器遍历完，zip就不再产生元组了，zip会提前终止，这可能导致意外的结果，不可不察。如果不能确定zip所封装的列表是否等长，可以改用 itertools 内置模块中的zip_longest 函数，这个函数不在乎它们的长度是否相等。

在Python2中，zip不是生成器，它平行地遍历这些迭代器，组装元组，并把这些元组所构成的列表一次性完整地返回，这可能会占用大量内存并导致程序崩溃，如果在Python2中要遍历数据量大的迭代器，推荐使用 itertools 内置模块中的 izip 函数。



## python 自动给数字前补0

Python中有一个zfill函数用来给字符串前面补0，非常有用，这个zfill看起来也就是zero fill的缩写。

~~~python
n = "123"
s = n.zfill(5)

>>> s = '00123'
~~~

zfill也可以给负数补0：

~~~python
n = '-123'
s = n.zfill(5)

>>> s = '-0123'
~~~

对于纯数字也可以通过格式化的方式来补0：

~~~python
n = 123
s = '%05d' % n

>>> s = '00123'
~~~



## 使用pip3 安装pandas报错

~~~
Command "python setup.py egg_info" failed with error code 1 in /tmp/pip-build-*
~~~

解决方法：

~~~~
pip3 install --upgrade pip
~~~~

 **参考**：https://www.cnblogs.com/xiao987334176/p/12600835.html